package com.qqq.thehomeofthecar;

import android.content.Intent;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.qqq.thehomeofthecar.adapter.recommendadapter.UseCarThreePictureDetailAdapter;
import com.qqq.thehomeofthecar.base.BaseActivity;
import com.qqq.thehomeofthecar.bean.UseCarThreePictureDetailBean;
import com.qqq.thehomeofthecar.util.VolleySingle;


/**
 * Created by 秦谦谦 on 16/5/17 16:36.
 */
public class UseCarThreePictureDetailActivity extends BaseActivity implements ViewPager.OnPageChangeListener, View.OnClickListener {
    private ViewPager viewPager;
    private UseCarThreePictureDetailAdapter useCarThreePictureDetailAdapter;
    private TextView title;
    private TextView content;
    private TextView replyCount;
    private TextView images;
    private TextView back;
    private UseCarThreePictureDetailBean useCarThreePictureDetailBean;

    @Override
    protected int getLayout() {
        return R.layout.activity_usecar_threepicturedetail;
    }

    @Override
    protected void initView() {
        viewPager = bindView(R.id.usecar_viewpager);
        title = bindView(R.id.usecar_tv_title);
        content = bindView(R.id.usecar_tv_content);
        replyCount=bindView(R.id.usecar_replycount);
        images=bindView(R.id.usecar_count);
        back=bindView(R.id.usecar_retuen_tv);


    }

    @Override
    protected void initData() {
        Intent intent = getIntent();
        String path = intent.getStringExtra("path");
        volley(path);
        viewPager.addOnPageChangeListener(this);
        back.setOnClickListener(this);
    }

    //数据解析
    private void volley(String path) {
        VolleySingle.addRequest(path, UseCarThreePictureDetailBean.class, new Response.Listener<UseCarThreePictureDetailBean>() {
            @Override
            public void onResponse(UseCarThreePictureDetailBean response) {
                useCarThreePictureDetailBean = response;
                useCarThreePictureDetailAdapter = new UseCarThreePictureDetailAdapter(useCarThreePictureDetailBean, getApplicationContext());
                viewPager.setAdapter(useCarThreePictureDetailAdapter);
                title.setText(useCarThreePictureDetailBean.getResult().getTitle());
                content.setText(useCarThreePictureDetailBean.getResult().getImages().get(0).getDescription());
                replyCount.setText(useCarThreePictureDetailBean.getResult().getReplycount()+"");

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
    }


    //监听页面的滑动
    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        content.setText(useCarThreePictureDetailBean.getResult().getImages().get(position).getDescription());
        images.setText(position+1 +"/"+(useCarThreePictureDetailBean.getResult().getImages().size()));

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    //返回事件
    @Override
    public void onClick(View v) {
        finish();
    }
}
