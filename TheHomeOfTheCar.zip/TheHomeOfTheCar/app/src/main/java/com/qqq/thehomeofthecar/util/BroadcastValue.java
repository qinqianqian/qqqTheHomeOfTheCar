package com.qqq.thehomeofthecar.util;

/**
 * Created by 秦谦谦 on 16/5/13 21:44.
 */
public class BroadcastValue {
    public static final String OPEN_DRAWLAYOUT_ALLBRADND="com.qqq.thehomeofthecar.openDraw";
}
