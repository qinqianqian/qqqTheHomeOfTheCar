package com.qqq.thehomeofthecar.adapter.recommendadapter;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.qqq.thehomeofthecar.R;
import com.qqq.thehomeofthecar.bean.UseCarThreePictureDetailBean;

import it.sephiroth.android.library.picasso.Picasso;

/**
 * Created by 秦谦谦 on 16/5/17 17:00.
 */
public class UseCarThreePictureDetailAdapter extends PagerAdapter {
    private UseCarThreePictureDetailBean useCarThreePictureDetailBean;
    private Context context;

    public UseCarThreePictureDetailAdapter(UseCarThreePictureDetailBean useCarThreePictureDetailBean, Context context) {
        this.useCarThreePictureDetailBean = useCarThreePictureDetailBean;
        this.context = context;
    }

    @Override
    public int getCount() {
        return useCarThreePictureDetailBean == null ? 0 : useCarThreePictureDetailBean.getResult().getImages().size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_usecar_threepicturedetail, container, false);
        ImageView imageView = (ImageView) view.findViewById(R.id.usecar_image);

        setImage(imageView, useCarThreePictureDetailBean.getResult().getImages().get(position).getImgurl());
        container.addView(view);
        return view;
    }

    public void setImage(ImageView imageView, String path) {
        Picasso.with(context).load(path).placeholder(R.mipmap.ahlib_common_main_filter_icon_f).error(R.mipmap.ahlib_common_main_filter_icon_p).into(imageView);

    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {

    }
}
