package com.qqq.thehomeofthecar.bean;

import android.graphics.Bitmap;

import java.util.BitSet;
import java.util.List;

/**
 * Created by 秦谦谦 on 16/5/14 10:22.
 */
public class BullectionDetailBean {

    /**
     * rowcount : 0
     * isloadmore : true
     * newsdata : {"newsid":309,"newstypeid":4,"newstypeanme":"其他快报","title":"科技前卫！亚洲CES展快报","summary":"1967年诞生，拥有49年历史的CES全称为国际消费电子产品展，这里一直是集聚全世界最前沿电子产业技术的\u201c盛宴\u201d，在那里超越这个时代的新创意，新技术将粉墨登场。去年5月上海承办了第一届亚洲CES展，今年它卷土重来。","newsstate":2,"showstate":1,"newsauthorid":4102,"newsauthor":"唐朝","img":"http://www2.autoimg.cn/newsdfs/g16/M00/73/C4/1024x768_0_autohomecar__wKgH5lctTw2AL3Z1AANsn81UI2w023.jpg","reviewcount":94413,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","createtime":"05/12 09:36","memberid":4940259,"headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtiptime":"1463025772"}
     * articlemodel : {}
     * messagelist : [{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g16/M06/78/91/620x0_0_autohomecar__wKgH11cykFSAQmWcAADwSkI6xaw553.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7961,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 09:52","publishtiptime":"1462931542","messagestate":1,"content":"10点整 作为ces媒体日第一场新闻发布会的雪佛兰品牌讲解即将开始。 我们已进入小屋中等待讲解","upcount":11,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605110952221377961","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g15/M14/79/ED/620x0_0_autohomecar__wKjByFcykWaAJD4OAACxzrTYJUY341.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7964,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 09:56","publishtiptime":"1462931816","messagestate":1,"content":"根据此前采集到的信息，此次雪佛兰将带来FNR概念车、迈锐宝XL混动车型以及官方定制车型","upcount":7,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605110956564007964","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g20/M0F/5A/5A/620x0_0_autohomecar__wKjBw1cylNCAXqjqAADhBIwjI9k981.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7967,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 10:11","publishtiptime":"1462932690","messagestate":1,"content":"讲解会开始 先回顾了下雪佛兰电子技术历史","upcount":7,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111011303137967","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g18/M0E/78/59/620x0_0_autohomecar__wKgH2VcymBSAaZZTAAFkd_WWVoo634.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7968,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 10:25","publishtiptime":"1462933526","messagestate":1,"content":"我们已经来到了CES展的现场，马上为大家带来第一手消息","upcount":8,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111025263277968","memberid":8328701},{"attachments":[{"attachtype":1,"picurl":"http://www2.autoimg.cn/newsdfs/g18/M03/77/F2/480x480_0_autohomecar__wKjBxVcymCiANHrWAAQUqvyGMvQ084.png","videourl":"http://v.autoimg.cn/v/app/2016/05/11/cf1578d1821a423285b72daaed0197e0.wm.m3u8","width":480,"height":480,"ordernum":0}],"commentlist":[{"userid":13330905,"username":"成都婚礼司仪曾诚","headimg":"","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"","sourcecontent":"","content":"我一直有个问题 为什么车载的平板反应和分辨率那么慢和低呢。价格也不便宜呀","createtime":"12小时前"}],"messageid":7969,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 10:25","publishtiptime":"1462933545","messagestate":1,"content":"四维图新推出了一款智能互联产品，可实现导航，音乐播放等基本功能，安卓和iOS系统都能支持","upcount":9,"replycount":1,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111025453577969","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g7/M05/79/30/620x0_0_autohomecar__wKgH3VcymLiAZKYgAAEX_ybvc2E629.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g7/M00/78/59/620x0_0_autohomecar__wKgHzlcymLqAIbzjAAFExzEl6h8374.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g7/M11/78/4C/620x0_0_autohomecar__wKjB0FcymL2AWTy8AAHM-zevdFA347.jpg","videourl":"","width":700,"height":933,"ordernum":0}],"commentlist":[{"userid":16025077,"username":"巨鼓","headimg":"http://i1.autoimg.cn/album/userheaders/2015/8/29/1423e64e-e9ac-41e6-a7df-bcfac4c11525_120X120.jpg","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"moon_lee","sourcecontent":"怎么出现了我的名字？","content":"原来你叫笑纳","createtime":"1天前"},{"userid":10432263,"username":"moon_lee","headimg":"http://i1.autoimg.cn/album/userheaders/2015/8/12/6fff67f1-7c13-4b64-ab55-5f4c407137c4_120X120.jpg","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"","sourcecontent":"","content":"怎么出现了我的名字？","createtime":"2天前"}],"messageid":7970,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 10:28","publishtiptime":"1462933729","messagestate":1,"content":"四维图新的趣驾功能在去年便已经推出，除了常见的音乐播放，导航之外，乘客还可以通过车机进行微信聊天，接收到的微信消息车机会自动语音播放","upcount":5,"replycount":2,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111028495977970","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g15/M03/76/87/620x0_0_autohomecar__wKgH5Vcymr6AFvHMAADR1KW8OYY574.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7974,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 10:36","publishtiptime":"1462934207","messagestate":1,"content":"未来 安吉星App也将支持手势操作","upcount":8,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111036478277974","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g16/M10/78/A7/620x0_0_autohomecar__wKgH11cynLGACg4CAAGAUmxHWjQ681.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7975,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 10:45","publishtiptime":"1462934706","messagestate":1,"content":"安吉星也在拓展自身功能，比如预定餐饮、预定高尔夫","upcount":3,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111045066937975","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g11/M03/78/D7/620x0_0_autohomecar__wKgH4VcynS-AMstvAADnZS-RhJM945.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g4/M00/77/F7/620x0_0_autohomecar__wKgHy1cynLWALW8vAADroM126gE900.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g4/M00/77/F7/620x0_0_autohomecar__wKgHy1cynLiAcHZIAADvQF0Viqk849.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7977,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 10:47","publishtiptime":"1462934832","messagestate":1,"content":"除了微信外，趣驾还可使用腾讯旗下的其他产品，如qq音乐，大众点评等","upcount":14,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111047120137977","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g9/M15/7C/73/620x0_0_autohomecar__wKgH31cynhKAABr1AADv77DGHYI499.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7978,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 10:50","publishtiptime":"1462935059","messagestate":1,"content":"趣驾功能已经配备在了哈弗H1上，未来也会有机会适配在更多车型上","upcount":9,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111050599507978","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g22/M11/5A/C4/620x0_0_autohomecar__wKjBwVcynkOAMad6AAGKuP3z7y4463.jpg","videourl":"","width":700,"height":933,"ordernum":0}],"commentlist":[],"messageid":7979,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 10:51","publishtiptime":"1462935108","messagestate":1,"content":"安吉星的预约餐饮功能相关页面","upcount":4,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111051488507979","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g13/M0D/79/0A/620x0_0_autohomecar__wKjBylcynnSAX9t8AAE4T4wffnM151.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g13/M09/78/FD/620x0_0_autohomecar__wKgH1FcynnWAK3fMAAD_IZc9X18899.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7980,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 10:52","publishtiptime":"1462935158","messagestate":1,"content":"安吉星与美的合作智能家居","upcount":3,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111052385337980","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g10/M15/79/0B/620x0_0_autohomecar__wKgH4FcynyaAPS9zAAIbio1CxD4193.jpg","videourl":"","width":700,"height":933,"ordernum":0}],"commentlist":[{"userid":25946239,"username":"181287245","headimg":"","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"","sourcecontent":"","content":"如果有这功能，苹果手表肯定大卖","createtime":"2天前"},{"userid":24590376,"username":"华子蓝","headimg":"","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"","sourcecontent":"","content":"人家叫Apple Watch","createtime":"2天前"}],"messageid":7982,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 10:55","publishtiptime":"1462935335","messagestate":1,"content":"未来使用iwatch，也可以控制车辆","upcount":8,"replycount":2,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111055353377982","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g18/M07/78/6C/620x0_0_autohomecar__wKgH2Vcyor-AHtJ1AAEUAl-8zPk801.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g18/M0C/78/6D/620x0_0_autohomecar__wKgH2VcyosKAfTS-AAFFhRxxxKI071.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7987,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 11:10","publishtiptime":"1462936258","messagestate":1,"content":"沃尔沃也将配备CarPlay功能，首先使用该功能的将会是XC90","upcount":7,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111110587707987","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g16/M02/78/B2/620x0_0_autohomecar__wKgH11cyo9CANtOCAAD0De1bfDw591.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g16/M01/78/F0/620x0_0_autohomecar__wKgH5lcyo9KASkiYAAFHur-hETs034.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7988,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 11:15","publishtiptime":"1462936530","messagestate":1,"content":"邮购商品不仅能送货上门，沃尔沃还推出了邮购到车的理念，可将邮购商品直接送上车","upcount":4,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111115306177988","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g15/M04/76/99/620x0_0_autohomecar__wKgH5VcypSKAR3XsAAEfnd3PSNA646.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g15/M0A/79/FD/620x0_0_autohomecar__wKgH1lcypSSAGpa3AAEDy-0NPEg431.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g15/M13/79/FD/620x0_0_autohomecar__wKgH1lcypSyABk6GAAD4JsbO9po615.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g15/M13/76/9B/620x0_0_autohomecar__wKgH5VcypS6AX5LEAAFaMeCNVmE493.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7990,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 11:21","publishtiptime":"1462936879","messagestate":1,"content":"沃尔沃将发布C26自动驾驶概念车，解放驾驶者的双手","upcount":3,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111121195507990","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g4/M05/78/0C/620x0_0_autohomecar__wKgHy1cyp--AOmViAADM24lnXNo210.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g4/M07/78/96/620x0_0_autohomecar__wKjB01cyp_KAM6HCAADOmwULRYk291.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g9/M10/7B/E6/620x0_0_autohomecar__wKgH0Fcyp_aAX7HuAAFCTWN6nCw432.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g9/M0C/7B/E9/620x0_0_autohomecar__wKgH0FcyqAWARva1AAFNtGElC0k976.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g9/M0D/72/D5/620x0_0_autohomecar__wKjBzlcyqAeANM3PAAEeyYO2udM571.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[{"userid":25130064,"username":"岳辣条","headimg":"","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"Design0403","sourcecontent":"遇事故是不是直接人进屏幕了？还是屏幕里面直接飞出一个气囊？","content":"666，直接进屏幕，可以穿越了","createtime":"1天前"},{"userid":5305672,"username":"Design0403","headimg":"http://i1.autoimg.cn/album/userheaders/2015/10/27/59a19dfd-8779-4d71-b3f5-bd6a0421ea20_120X120.jpg","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"","sourcecontent":"","content":"遇事故是不是直接人进屏幕了？还是屏幕里面直接飞出一个气囊？","createtime":"2天前"},{"userid":8328701,"username":"无水菠萝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"车开车往","sourcecontent":"翻过来不是没空调吹了","content":"目前仅仅是个概念","createtime":"2天前"}],"messageid":7991,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 11:33","publishtiptime":"1462937608","messagestate":1,"content":" 沃尔沃C26自动驾驶概念车，副驾驶座前方是一块可翻转，尺寸超大的屏幕","upcount":7,"replycount":5,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111133286907991","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g20/M05/5B/05/620x0_0_autohomecar__wKgFVFcyseKAPexeAADwI_stLF0530.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g20/M07/5A/82/620x0_0_autohomecar__wKjBw1cyseSAERUkAAEYEWuipNA586.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g20/M0B/5B/06/620x0_0_autohomecar__wKgFVFcyseWAabZMAAD_VM9GmMI114.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g20/M08/5B/38/620x0_0_autohomecar__wKgFWVcysemAYnHcAAFywpIK2IM986.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7993,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 12:15","publishtiptime":"1462940138","messagestate":1,"content":"先锋展台的驾驶模拟系统主要体验的是其最新的人机交互功能","upcount":5,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111215387307993","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g18/M06/78/81/620x0_0_autohomecar__wKgH2Vcys6GAcrXQAAHiAipJRVc888.jpg","videourl":"","width":700,"height":933,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g18/M06/78/81/620x0_0_autohomecar__wKgH2Vcys6OANuNlAAGH5v1Ansc349.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g18/M0A/78/94/620x0_0_autohomecar__wKgH6Fcys6aAICqxAAGfvDCzw-A273.jpg","videourl":"","width":700,"height":933,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g18/M0D/78/82/620x0_0_autohomecar__wKgH2Vcys6iAfXQlAADNCp5Ewio664.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g18/M10/78/17/620x0_0_autohomecar__wKjBxVcys7SAPDAqAAIiBcU8ozA774.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g18/M09/78/84/620x0_0_autohomecar__wKgH2Vcys7iAV24kAAFvi3JJx9A385.jpg","videourl":"","width":700,"height":933,"ordernum":0}],"commentlist":[{"userid":8328701,"username":"无水菠萝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"这个汽车会秒人","sourcecontent":"展馆对消费者开放吗？","content":"开放的","createtime":"2天前"},{"userid":14336465,"username":"江南巷口晒太阳","headimg":"http://i1.autoimg.cn/album/userheaders/g5/M14/71/B2/120X120_0_q87_autohomecar__wKgHzFcrJ3OANGFOAAAwlYFhG1s941.jpg","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"","sourcecontent":"","content":"看到百度真是日了狗","createtime":"2天前"},{"userid":9382715,"username":"这个汽车会秒人","headimg":"http://i1.autoimg.cn/album/userheaders/2015/10/23/f3b8cc52-94b6-4f69-899d-0173d3e8c65e_120X120.jpg","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"","sourcecontent":"","content":"展馆对消费者开放吗？","createtime":"2天前"}],"messageid":7994,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 12:23","publishtiptime":"1462940601","messagestate":1,"content":"先锋还在现场还可进行百度CarLife，四维图新WeLink以及苹果CarPlay三种互联系统的体验，三种系统的主要功能基本相同","upcount":4,"replycount":3,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111223210937994","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g5/M0E/78/E3/620x0_0_autohomecar__wKgHzFcyv9qAEpdKAAEOgA7H0QU501.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g4/M0E/78/28/620x0_0_autohomecar__wKgHy1cyv9yAPApGAAEo-4LKGuw849.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7996,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 13:15","publishtiptime":"1462943709","messagestate":1,"content":"大陆集团与三星合作开发了一款能够与手表互联的仪表系统，两者通过蓝牙连接，目前还在研发阶段","upcount":5,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111315091737996","memberid":8328701}]
     * canedit : false
     */

    private ResultBean result;
    /**
     * result : {"rowcount":0,"isloadmore":true,"newsdata":{"newsid":309,"newstypeid":4,"newstypeanme":"其他快报","title":"科技前卫！亚洲CES展快报","summary":"1967年诞生，拥有49年历史的CES全称为国际消费电子产品展，这里一直是集聚全世界最前沿电子产业技术的\u201c盛宴\u201d，在那里超越这个时代的新创意，新技术将粉墨登场。去年5月上海承办了第一届亚洲CES展，今年它卷土重来。","newsstate":2,"showstate":1,"newsauthorid":4102,"newsauthor":"唐朝","img":"http://www2.autoimg.cn/newsdfs/g16/M00/73/C4/1024x768_0_autohomecar__wKgH5lctTw2AL3Z1AANsn81UI2w023.jpg","reviewcount":94413,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","createtime":"05/12 09:36","memberid":4940259,"headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtiptime":"1463025772"},"articlemodel":{},"messagelist":[{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g16/M06/78/91/620x0_0_autohomecar__wKgH11cykFSAQmWcAADwSkI6xaw553.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7961,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 09:52","publishtiptime":"1462931542","messagestate":1,"content":"10点整 作为ces媒体日第一场新闻发布会的雪佛兰品牌讲解即将开始。 我们已进入小屋中等待讲解","upcount":11,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605110952221377961","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g15/M14/79/ED/620x0_0_autohomecar__wKjByFcykWaAJD4OAACxzrTYJUY341.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7964,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 09:56","publishtiptime":"1462931816","messagestate":1,"content":"根据此前采集到的信息，此次雪佛兰将带来FNR概念车、迈锐宝XL混动车型以及官方定制车型","upcount":7,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605110956564007964","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g20/M0F/5A/5A/620x0_0_autohomecar__wKjBw1cylNCAXqjqAADhBIwjI9k981.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7967,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 10:11","publishtiptime":"1462932690","messagestate":1,"content":"讲解会开始 先回顾了下雪佛兰电子技术历史","upcount":7,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111011303137967","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g18/M0E/78/59/620x0_0_autohomecar__wKgH2VcymBSAaZZTAAFkd_WWVoo634.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7968,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 10:25","publishtiptime":"1462933526","messagestate":1,"content":"我们已经来到了CES展的现场，马上为大家带来第一手消息","upcount":8,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111025263277968","memberid":8328701},{"attachments":[{"attachtype":1,"picurl":"http://www2.autoimg.cn/newsdfs/g18/M03/77/F2/480x480_0_autohomecar__wKjBxVcymCiANHrWAAQUqvyGMvQ084.png","videourl":"http://v.autoimg.cn/v/app/2016/05/11/cf1578d1821a423285b72daaed0197e0.wm.m3u8","width":480,"height":480,"ordernum":0}],"commentlist":[{"userid":13330905,"username":"成都婚礼司仪曾诚","headimg":"","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"","sourcecontent":"","content":"我一直有个问题 为什么车载的平板反应和分辨率那么慢和低呢。价格也不便宜呀","createtime":"12小时前"}],"messageid":7969,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 10:25","publishtiptime":"1462933545","messagestate":1,"content":"四维图新推出了一款智能互联产品，可实现导航，音乐播放等基本功能，安卓和iOS系统都能支持","upcount":9,"replycount":1,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111025453577969","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g7/M05/79/30/620x0_0_autohomecar__wKgH3VcymLiAZKYgAAEX_ybvc2E629.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g7/M00/78/59/620x0_0_autohomecar__wKgHzlcymLqAIbzjAAFExzEl6h8374.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g7/M11/78/4C/620x0_0_autohomecar__wKjB0FcymL2AWTy8AAHM-zevdFA347.jpg","videourl":"","width":700,"height":933,"ordernum":0}],"commentlist":[{"userid":16025077,"username":"巨鼓","headimg":"http://i1.autoimg.cn/album/userheaders/2015/8/29/1423e64e-e9ac-41e6-a7df-bcfac4c11525_120X120.jpg","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"moon_lee","sourcecontent":"怎么出现了我的名字？","content":"原来你叫笑纳","createtime":"1天前"},{"userid":10432263,"username":"moon_lee","headimg":"http://i1.autoimg.cn/album/userheaders/2015/8/12/6fff67f1-7c13-4b64-ab55-5f4c407137c4_120X120.jpg","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"","sourcecontent":"","content":"怎么出现了我的名字？","createtime":"2天前"}],"messageid":7970,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 10:28","publishtiptime":"1462933729","messagestate":1,"content":"四维图新的趣驾功能在去年便已经推出，除了常见的音乐播放，导航之外，乘客还可以通过车机进行微信聊天，接收到的微信消息车机会自动语音播放","upcount":5,"replycount":2,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111028495977970","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g15/M03/76/87/620x0_0_autohomecar__wKgH5Vcymr6AFvHMAADR1KW8OYY574.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7974,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 10:36","publishtiptime":"1462934207","messagestate":1,"content":"未来 安吉星App也将支持手势操作","upcount":8,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111036478277974","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g16/M10/78/A7/620x0_0_autohomecar__wKgH11cynLGACg4CAAGAUmxHWjQ681.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7975,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 10:45","publishtiptime":"1462934706","messagestate":1,"content":"安吉星也在拓展自身功能，比如预定餐饮、预定高尔夫","upcount":3,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111045066937975","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g11/M03/78/D7/620x0_0_autohomecar__wKgH4VcynS-AMstvAADnZS-RhJM945.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g4/M00/77/F7/620x0_0_autohomecar__wKgHy1cynLWALW8vAADroM126gE900.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g4/M00/77/F7/620x0_0_autohomecar__wKgHy1cynLiAcHZIAADvQF0Viqk849.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7977,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 10:47","publishtiptime":"1462934832","messagestate":1,"content":"除了微信外，趣驾还可使用腾讯旗下的其他产品，如qq音乐，大众点评等","upcount":14,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111047120137977","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g9/M15/7C/73/620x0_0_autohomecar__wKgH31cynhKAABr1AADv77DGHYI499.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7978,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 10:50","publishtiptime":"1462935059","messagestate":1,"content":"趣驾功能已经配备在了哈弗H1上，未来也会有机会适配在更多车型上","upcount":9,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111050599507978","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g22/M11/5A/C4/620x0_0_autohomecar__wKjBwVcynkOAMad6AAGKuP3z7y4463.jpg","videourl":"","width":700,"height":933,"ordernum":0}],"commentlist":[],"messageid":7979,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 10:51","publishtiptime":"1462935108","messagestate":1,"content":"安吉星的预约餐饮功能相关页面","upcount":4,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111051488507979","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g13/M0D/79/0A/620x0_0_autohomecar__wKjBylcynnSAX9t8AAE4T4wffnM151.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g13/M09/78/FD/620x0_0_autohomecar__wKgH1FcynnWAK3fMAAD_IZc9X18899.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7980,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 10:52","publishtiptime":"1462935158","messagestate":1,"content":"安吉星与美的合作智能家居","upcount":3,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111052385337980","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g10/M15/79/0B/620x0_0_autohomecar__wKgH4FcynyaAPS9zAAIbio1CxD4193.jpg","videourl":"","width":700,"height":933,"ordernum":0}],"commentlist":[{"userid":25946239,"username":"181287245","headimg":"","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"","sourcecontent":"","content":"如果有这功能，苹果手表肯定大卖","createtime":"2天前"},{"userid":24590376,"username":"华子蓝","headimg":"","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"","sourcecontent":"","content":"人家叫Apple Watch","createtime":"2天前"}],"messageid":7982,"authorid":4102,"authorname":"唐朝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg","publishtime":"05/11 10:55","publishtiptime":"1462935335","messagestate":1,"content":"未来使用iwatch，也可以控制车辆","upcount":8,"replycount":2,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111055353377982","memberid":4940259},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g18/M07/78/6C/620x0_0_autohomecar__wKgH2Vcyor-AHtJ1AAEUAl-8zPk801.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g18/M0C/78/6D/620x0_0_autohomecar__wKgH2VcyosKAfTS-AAFFhRxxxKI071.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7987,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 11:10","publishtiptime":"1462936258","messagestate":1,"content":"沃尔沃也将配备CarPlay功能，首先使用该功能的将会是XC90","upcount":7,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111110587707987","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g16/M02/78/B2/620x0_0_autohomecar__wKgH11cyo9CANtOCAAD0De1bfDw591.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g16/M01/78/F0/620x0_0_autohomecar__wKgH5lcyo9KASkiYAAFHur-hETs034.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7988,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 11:15","publishtiptime":"1462936530","messagestate":1,"content":"邮购商品不仅能送货上门，沃尔沃还推出了邮购到车的理念，可将邮购商品直接送上车","upcount":4,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111115306177988","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g15/M04/76/99/620x0_0_autohomecar__wKgH5VcypSKAR3XsAAEfnd3PSNA646.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g15/M0A/79/FD/620x0_0_autohomecar__wKgH1lcypSSAGpa3AAEDy-0NPEg431.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g15/M13/79/FD/620x0_0_autohomecar__wKgH1lcypSyABk6GAAD4JsbO9po615.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g15/M13/76/9B/620x0_0_autohomecar__wKgH5VcypS6AX5LEAAFaMeCNVmE493.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7990,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 11:21","publishtiptime":"1462936879","messagestate":1,"content":"沃尔沃将发布C26自动驾驶概念车，解放驾驶者的双手","upcount":3,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111121195507990","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g4/M05/78/0C/620x0_0_autohomecar__wKgHy1cyp--AOmViAADM24lnXNo210.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g4/M07/78/96/620x0_0_autohomecar__wKjB01cyp_KAM6HCAADOmwULRYk291.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g9/M10/7B/E6/620x0_0_autohomecar__wKgH0Fcyp_aAX7HuAAFCTWN6nCw432.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g9/M0C/7B/E9/620x0_0_autohomecar__wKgH0FcyqAWARva1AAFNtGElC0k976.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g9/M0D/72/D5/620x0_0_autohomecar__wKjBzlcyqAeANM3PAAEeyYO2udM571.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[{"userid":25130064,"username":"岳辣条","headimg":"","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"Design0403","sourcecontent":"遇事故是不是直接人进屏幕了？还是屏幕里面直接飞出一个气囊？","content":"666，直接进屏幕，可以穿越了","createtime":"1天前"},{"userid":5305672,"username":"Design0403","headimg":"http://i1.autoimg.cn/album/userheaders/2015/10/27/59a19dfd-8779-4d71-b3f5-bd6a0421ea20_120X120.jpg","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"","sourcecontent":"","content":"遇事故是不是直接人进屏幕了？还是屏幕里面直接飞出一个气囊？","createtime":"2天前"},{"userid":8328701,"username":"无水菠萝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"车开车往","sourcecontent":"翻过来不是没空调吹了","content":"目前仅仅是个概念","createtime":"2天前"}],"messageid":7991,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 11:33","publishtiptime":"1462937608","messagestate":1,"content":" 沃尔沃C26自动驾驶概念车，副驾驶座前方是一块可翻转，尺寸超大的屏幕","upcount":7,"replycount":5,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111133286907991","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g20/M05/5B/05/620x0_0_autohomecar__wKgFVFcyseKAPexeAADwI_stLF0530.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g20/M07/5A/82/620x0_0_autohomecar__wKjBw1cyseSAERUkAAEYEWuipNA586.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g20/M0B/5B/06/620x0_0_autohomecar__wKgFVFcyseWAabZMAAD_VM9GmMI114.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g20/M08/5B/38/620x0_0_autohomecar__wKgFWVcysemAYnHcAAFywpIK2IM986.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7993,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 12:15","publishtiptime":"1462940138","messagestate":1,"content":"先锋展台的驾驶模拟系统主要体验的是其最新的人机交互功能","upcount":5,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111215387307993","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g18/M06/78/81/620x0_0_autohomecar__wKgH2Vcys6GAcrXQAAHiAipJRVc888.jpg","videourl":"","width":700,"height":933,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g18/M06/78/81/620x0_0_autohomecar__wKgH2Vcys6OANuNlAAGH5v1Ansc349.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g18/M0A/78/94/620x0_0_autohomecar__wKgH6Fcys6aAICqxAAGfvDCzw-A273.jpg","videourl":"","width":700,"height":933,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g18/M0D/78/82/620x0_0_autohomecar__wKgH2Vcys6iAfXQlAADNCp5Ewio664.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g18/M10/78/17/620x0_0_autohomecar__wKjBxVcys7SAPDAqAAIiBcU8ozA774.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g18/M09/78/84/620x0_0_autohomecar__wKgH2Vcys7iAV24kAAFvi3JJx9A385.jpg","videourl":"","width":700,"height":933,"ordernum":0}],"commentlist":[{"userid":8328701,"username":"无水菠萝","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"这个汽车会秒人","sourcecontent":"展馆对消费者开放吗？","content":"开放的","createtime":"2天前"},{"userid":14336465,"username":"江南巷口晒太阳","headimg":"http://i1.autoimg.cn/album/userheaders/g5/M14/71/B2/120X120_0_q87_autohomecar__wKgHzFcrJ3OANGFOAAAwlYFhG1s941.jpg","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"","sourcecontent":"","content":"看到百度真是日了狗","createtime":"2天前"},{"userid":9382715,"username":"这个汽车会秒人","headimg":"http://i1.autoimg.cn/album/userheaders/2015/10/23/f3b8cc52-94b6-4f69-899d-0173d3e8c65e_120X120.jpg","issocialize":0,"iscarower":0,"isbusinessauth":0,"carname":"","sourcename":"","sourcecontent":"","content":"展馆对消费者开放吗？","createtime":"2天前"}],"messageid":7994,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 12:23","publishtiptime":"1462940601","messagestate":1,"content":"先锋还在现场还可进行百度CarLife，四维图新WeLink以及苹果CarPlay三种互联系统的体验，三种系统的主要功能基本相同","upcount":4,"replycount":3,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111223210937994","memberid":8328701},{"attachments":[{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g5/M0E/78/E3/620x0_0_autohomecar__wKgHzFcyv9qAEpdKAAEOgA7H0QU501.jpg","videourl":"","width":700,"height":525,"ordernum":0},{"attachtype":0,"picurl":"http://www2.autoimg.cn/newsdfs/g4/M0E/78/28/620x0_0_autohomecar__wKgHy1cyv9yAPApGAAEo-4LKGuw849.jpg","videourl":"","width":700,"height":525,"ordernum":0}],"commentlist":[],"messageid":7996,"authorid":4870,"authorname":"朱力神","headimg":"http://i1.autoimg.cn/album/userheaders/2015/3/9/0895960c-b533-41a2-951c-b16501821a70_120X120.jpg","publishtime":"05/11 13:15","publishtiptime":"1462943709","messagestate":1,"content":"大陆集团与三星合作开发了一款能够与手表互联的仪表系统，两者通过蓝牙连接，目前还在研发阶段","upcount":5,"replycount":0,"shareimg":"http://app0.autoimg.cn/autoapp/dis/logo180.png","pageid":"201605111315091737996","memberid":8328701}],"canedit":false}
     * returncode : 0
     * message :
     */

    private int returncode;
    private String message;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class ResultBean {
        private int rowcount;
        private boolean isloadmore;
        /**
         * newsid : 309
         * newstypeid : 4
         * newstypeanme : 其他快报
         * title : 科技前卫！亚洲CES展快报
         * summary : 1967年诞生，拥有49年历史的CES全称为国际消费电子产品展，这里一直是集聚全世界最前沿电子产业技术的“盛宴”，在那里超越这个时代的新创意，新技术将粉墨登场。去年5月上海承办了第一届亚洲CES展，今年它卷土重来。
         * newsstate : 2
         * showstate : 1
         * newsauthorid : 4102
         * newsauthor : 唐朝
         * img : http://www2.autoimg.cn/newsdfs/g16/M00/73/C4/1024x768_0_autohomecar__wKgH5lctTw2AL3Z1AANsn81UI2w023.jpg
         * reviewcount : 94413
         * shareimg : http://app0.autoimg.cn/autoapp/dis/logo180.png
         * createtime : 05/12 09:36
         * memberid : 4940259
         * headimg : http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg
         * publishtiptime : 1463025772
         */

        private NewsdataBean newsdata;
        private ArticlemodelBean articlemodel;
        private boolean canedit;
        /**
         * attachments : [{"attachtype":0,"picurl":"http://www3.autoimg.cn/newsdfs/g16/M06/78/91/620x0_0_autohomecar__wKgH11cykFSAQmWcAADwSkI6xaw553.jpg","videourl":"","width":700,"height":525,"ordernum":0}]
         * commentlist : []
         * messageid : 7961
         * authorid : 4102
         * authorname : 唐朝
         * headimg : http://i1.autoimg.cn/album/userheaders/2015/4/17/45ebc4fc-6196-4f9e-897b-8ac76e1ed803_120X120.jpg
         * publishtime : 05/11 09:52
         * publishtiptime : 1462931542
         * messagestate : 1
         * content : 10点整 作为ces媒体日第一场新闻发布会的雪佛兰品牌讲解即将开始。 我们已进入小屋中等待讲解
         * upcount : 11
         * replycount : 0
         * shareimg : http://app0.autoimg.cn/autoapp/dis/logo180.png
         * pageid : 201605110952221377961
         * memberid : 4940259
         */

        private List<MessagelistBean> messagelist;

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public boolean isIsloadmore() {
            return isloadmore;
        }

        public void setIsloadmore(boolean isloadmore) {
            this.isloadmore = isloadmore;
        }

        public NewsdataBean getNewsdata() {
            return newsdata;
        }

        public void setNewsdata(NewsdataBean newsdata) {
            this.newsdata = newsdata;
        }

        public ArticlemodelBean getArticlemodel() {
            return articlemodel;
        }

        public void setArticlemodel(ArticlemodelBean articlemodel) {
            this.articlemodel = articlemodel;
        }

        public boolean isCanedit() {
            return canedit;
        }

        public void setCanedit(boolean canedit) {
            this.canedit = canedit;
        }

        public List<MessagelistBean> getMessagelist() {
            return messagelist;
        }

        public void setMessagelist(List<MessagelistBean> messagelist) {
            this.messagelist = messagelist;
        }

        public static class NewsdataBean {
            private int newsid;
            private int newstypeid;
            private String newstypeanme;
            private String title;
            private String summary;
            private int newsstate;
            private int showstate;
            private int newsauthorid;
            private String newsauthor;
            private int reviewcount;
            private String createtime;
            private String img;
            private String  headimg;

            public String getCreatetime() {
                return createtime;
            }

            public void setCreatetime(String createtime) {
                this.createtime = createtime;
            }

            public String  getImg() {
                return img;
            }

            public void setImg(String img) {
                this.img = img;
            }

            public String getHeadimg() {
                return headimg;
            }

            public void setHeadimg(String headimg) {
                this.headimg = headimg;
            }

            public int getReviewcount() {
                return reviewcount;
            }

            public void setReviewcount(int reviewcount) {
                this.reviewcount = reviewcount;
            }

            public int getNewsid() {
                return newsid;
            }

            public void setNewsid(int newsid) {
                this.newsid = newsid;
            }

            public int getNewstypeid() {
                return newstypeid;
            }

            public void setNewstypeid(int newstypeid) {
                this.newstypeid = newstypeid;
            }

            public String getNewstypeanme() {
                return newstypeanme;
            }

            public void setNewstypeanme(String newstypeanme) {
                this.newstypeanme = newstypeanme;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getSummary() {
                return summary;
            }

            public void setSummary(String summary) {
                this.summary = summary;
            }

            public int getNewsstate() {
                return newsstate;
            }

            public void setNewsstate(int newsstate) {
                this.newsstate = newsstate;
            }

            public int getShowstate() {
                return showstate;
            }

            public void setShowstate(int showstate) {
                this.showstate = showstate;
            }

            public int getNewsauthorid() {
                return newsauthorid;
            }

            public void setNewsauthorid(int newsauthorid) {
                this.newsauthorid = newsauthorid;
            }

            public String getNewsauthor() {
                return newsauthor;
            }

            public void setNewsauthor(String newsauthor) {
                this.newsauthor = newsauthor;
            }
        }

        public static class ArticlemodelBean {
        }

        public static class MessagelistBean {
            private int messageid;
            private int authorid;
            private String authorname;
            private String headimg;
            private String publishtime;
            private String publishtiptime;
            private int messagestate;
            private String content;
            private int upcount;
            private int replycount;
            private String shareimg;
            private String pageid;
            private int memberid;
            private String picurl;

            public String getPicurl() {
                return picurl;
            }

            public void setPicurl(String picurl) {
                this.picurl = picurl;
            }

            /**
             * attachtype : 0
             * picurl : http://www3.autoimg.cn/newsdfs/g16/M06/78/91/620x0_0_autohomecar__wKgH11cykFSAQmWcAADwSkI6xaw553.jpg
             * videourl :
             * width : 700
             * height : 525
             * ordernum : 0
             */

            private List<AttachmentsBean> attachments;
            private List<?> commentlist;

            public int getMessageid() {
                return messageid;
            }

            public void setMessageid(int messageid) {
                this.messageid = messageid;
            }

            public int getAuthorid() {
                return authorid;
            }

            public void setAuthorid(int authorid) {
                this.authorid = authorid;
            }

            public String getAuthorname() {
                return authorname;
            }

            public void setAuthorname(String authorname) {
                this.authorname = authorname;
            }

            public String getHeadimg() {
                return headimg;
            }

            public void setHeadimg(String headimg) {
                this.headimg = headimg;
            }

            public String getPublishtime() {
                return publishtime;
            }

            public void setPublishtime(String publishtime) {
                this.publishtime = publishtime;
            }

            public String getPublishtiptime() {
                return publishtiptime;
            }

            public void setPublishtiptime(String publishtiptime) {
                this.publishtiptime = publishtiptime;
            }

            public int getMessagestate() {
                return messagestate;
            }

            public void setMessagestate(int messagestate) {
                this.messagestate = messagestate;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public int getUpcount() {
                return upcount;
            }

            public void setUpcount(int upcount) {
                this.upcount = upcount;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public String getShareimg() {
                return shareimg;
            }

            public void setShareimg(String shareimg) {
                this.shareimg = shareimg;
            }

            public String getPageid() {
                return pageid;
            }

            public void setPageid(String pageid) {
                this.pageid = pageid;
            }

            public int getMemberid() {
                return memberid;
            }

            public void setMemberid(int memberid) {
                this.memberid = memberid;
            }

            public List<AttachmentsBean> getAttachments() {
                return attachments;
            }

            public void setAttachments(List<AttachmentsBean> attachments) {
                this.attachments = attachments;
            }

            public List<?> getCommentlist() {
                return commentlist;
            }

            public void setCommentlist(List<?> commentlist) {
                this.commentlist = commentlist;
            }

            public static class AttachmentsBean {
                private int attachtype;
                private String picurl;
                private String videourl;
                private int width;
                private int height;
                private int ordernum;

                public int getAttachtype() {
                    return attachtype;
                }

                public void setAttachtype(int attachtype) {
                    this.attachtype = attachtype;
                }

                public String getPicurl() {
                    return picurl;
                }

                public void setPicurl(String picurl) {
                    this.picurl = picurl;
                }

                public String getVideourl() {
                    return videourl;
                }

                public void setVideourl(String videourl) {
                    this.videourl = videourl;
                }

                public int getWidth() {
                    return width;
                }

                public void setWidth(int width) {
                    this.width = width;
                }

                public int getHeight() {
                    return height;
                }

                public void setHeight(int height) {
                    this.height = height;
                }

                public int getOrdernum() {
                    return ordernum;
                }

                public void setOrdernum(int ordernum) {
                    this.ordernum = ordernum;
                }
            }
        }
    }
}
