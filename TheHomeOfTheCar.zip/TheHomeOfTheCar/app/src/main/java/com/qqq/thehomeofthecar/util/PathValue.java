package com.qqq.thehomeofthecar.util;

/**
 * Created by 秦谦谦 on 16/5/11 17:56.
 */
public class PathValue {
    public static final String NEWS_FRAGMEENT_HOME_PAGE="http://app.api.autohome.com.cn/autov5.0.0/news/newslist-pm1-c0-nt1-p1-s30-l0.json";
    public static final String NEW_FRAGMENT_HOME_PAGE="http://app.api.autohome.com.cn/autov4.2.5/news/newslist-a2-pm1-v4.2.5-c0-nt0-p1-s30-l0.html";
    public  static final String BULLECTION_FRAGMENT_HOME_PAGE="http://app.api.autohome.com.cn/autov5.0.0/news/fastnewslist-pm2-b0-l0-s20-lastid0.json";
    public static final String VIDEO_FRAGMENT_HOME_PAGE="http://app.api.autohome.com.cn/autov5.0.0/news/videolist-pm2-vt0-s20-lastid0.json";
    public static final String USECAR_FRAGMENT_HOME_PAGE="http://app.api.autohome.com.cn/autov5.0.0/news/newslist-pm2-c0-nt82-p1-s20-l0.json";
}
