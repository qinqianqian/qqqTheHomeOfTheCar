package com.qqq.thehomeofthecar.bean;

import java.util.List;

/**
 * Created by 秦谦谦 on 16/5/17 11:24.
 */
public class VideoFragmentBean {

    /**
     * isloadmore : true
     * rowcount : 67274
     * pagecount : 3204
     * pageindex : 0
     * list : [{"id":80676,"title":"《爱极客》 虽安逸 待变革之沃尔沃XC60","type":"花边","time":"2016-05-17","indexdetail":"爱极客原创视频","smallimg":"http://www2.autoimg.cn/newsdfs/g12/M0D/81/FC/120x90_0_autohomecar__wKgH4lc6hR6AEMnqAAG9zW97cwg773.jpg","replycount":2,"playcount":167,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80676.html","updatetime":"20160517104239","lastid":"201605171042402016051710432480676"},{"id":80633,"title":"能拉又能跑 海外试驾本田Ridgeline","type":"试车","time":"2016-05-17","indexdetail":"视频中主持人带来了本田Ridgeline的试驾，它搭载一台来自Pilot的3.5L V6发动机，同时，该车还将装配一套全时四驱系统。","smallimg":"http://www3.autoimg.cn/newsdfs/g17/M10/79/AA/120x90_0_autohomecar__wKjBxlc5cuiACb_qAAFdfYNR2-k538.jpg","replycount":47,"playcount":20346,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_2_80633.html","updatetime":"20160516164339","lastid":"201605170015052016051708513280633"},{"id":80609,"title":"福特F-150 Raptor/Titan XD全面对比","type":"花边","time":"2016-05-16","indexdetail":"视频展示了福特F-150 Raptor与日产Titan XD的全面对比。让我们来看看谁才是硬汉？","smallimg":"http://www2.autoimg.cn/newsdfs/g17/M00/7A/3D/120x90_0_autohomecar__wKgH51c5LiqAXpzgAAFbbPybbDM203.jpg","replycount":14,"playcount":8476,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80609.html","updatetime":"20160516171842","lastid":"201605161718422016051708350080609"},{"id":80593,"title":"经典时刻 最年轻的F1世界冠军TOP 5","type":"花边","time":"2016-05-16","indexdetail":"视频盘点了史上最年轻的F1世界冠军TOP 5。如果你了解F1的话，看看你又认识几位？","smallimg":"http://www2.autoimg.cn/newsdfs/g13/M04/7E/C7/120x90_0_autohomecar__wKgH1Fc5KC6AP4h8AAE2I1ogSeU206.jpg","replycount":17,"playcount":6671,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80593.html","updatetime":"20160516171643","lastid":"201605161716442016051708350080593"},{"id":80631,"title":"太残忍了 实拍小轿车路口被撞成两半","type":"花边","time":"2016-05-16","indexdetail":"太残忍了 实拍小轿车路口被撞成两半","smallimg":"http://www2.autoimg.cn/newsdfs/g14/M12/7D/F2/120x90_0_autohomecar__wKjByVc5YDmAHJRoAAEAS2xdms8722.jpg","replycount":85,"playcount":44354,"nickname":"崔海","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80631.html","updatetime":"20160516135300","lastid":"201605161353002016051708350080631"},{"id":80615,"title":"机增VS自吸 川崎H2加速战宝马S1000RR","type":"花边","time":"2016-05-16","indexdetail":" 机增VS自吸 川崎H2加速战宝马S1000RR ","smallimg":"http://www2.autoimg.cn/newsdfs/g8/M14/81/92/120x90_0_autohomecar__wKgHz1c5Nw6AUT2CAAEh_Log-Tk303.jpg","replycount":93,"playcount":34939,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80615.html","updatetime":"20160516105721","lastid":"201605161057212016051708350080615"},{"id":80614,"title":"超载了吧？实拍手扶拖拉机失控翻车","type":"花边","time":"2016-05-16","indexdetail":" 超载了吧？实拍手扶拖拉机失控翻车 ","smallimg":"http://www2.autoimg.cn/newsdfs/g16/M04/7E/D7/120x90_0_autohomecar__wKgH5lc5NoiABZPeAAFBt1LQq-0322.jpg","replycount":35,"playcount":11844,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80614.html","updatetime":"20160516105505","lastid":"201605161055062016051708350080614"},{"id":80613,"title":"这得多快的速度 摩托车路口追尾撞散架","type":"花边","time":"2016-05-16","indexdetail":"视频中的摩托车高速追尾一辆机动车，摩托车散架，画面相当恐怖。","smallimg":"http://www2.autoimg.cn/newsdfs/g10/M15/7F/03/120x90_0_autohomecar__wKgH4Fc5NlWAQ0OLAAFJ3F60o4I047.jpg","replycount":47,"playcount":16869,"nickname":"崔海","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80613.html","updatetime":"20160516105418","lastid":"201605161054182016051708350080613"},{"id":80603,"title":"美式狠角色 道奇蝰蛇400米暴强加速集锦","type":"花边","time":"2016-05-16","indexdetail":"道奇蝰蛇400米暴强加速集锦","smallimg":"http://www3.autoimg.cn/newsdfs/g16/M07/7E/89/120x90_0_autohomecar__wKgH11c5LBqAeXjkAAE_fX7yuhw862.jpg","replycount":38,"playcount":12153,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80603.html","updatetime":"20160517084753","lastid":"201605161010352016051708350080603"},{"id":80601,"title":"这么用功 女司机驾车途中玩电脑入神","type":"花边","time":"2016-05-16","indexdetail":"视频中的女司机在路口等红灯的时候玩电脑，一秒钟都不浪费。","smallimg":"http://www2.autoimg.cn/newsdfs/g9/M06/82/44/120x90_0_autohomecar__wKgH31c5K6OATvxjAAEmwp2-kDI018.jpg","replycount":6,"playcount":4983,"nickname":"崔海","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80601.html","updatetime":"20160516100836","lastid":"201605161008372016051708350080601"},{"id":80595,"title":"加速凶猛！福特野马GT350R赛道飞驰","type":"花边","time":"2016-05-16","indexdetail":"福特野马GT350R赛道飞驰","smallimg":"http://www2.autoimg.cn/newsdfs/g15/M03/7C/72/120x90_0_autohomecar__wKgH5Vc5KKyAJQmOAAEwLV3L_CE149.jpg","replycount":6,"playcount":5145,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80595.html","updatetime":"20160516095558","lastid":"201605160955582016051708350080595"},{"id":80589,"title":"帅！帕加尼Huayra BC冰天雪地测试性能","type":"花边","time":"2016-05-16","indexdetail":"帕加尼Huayra BC冰天雪地测试性能","smallimg":"http://www3.autoimg.cn/newsdfs/g6/M04/7E/2F/120x90_0_autohomecar__wKjB0Vc5J2-AJtkIAACqB7uVD4s649.jpg","replycount":8,"playcount":4144,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80589.html","updatetime":"20160516095040","lastid":"201605160950402016051708350080589"},{"id":80585,"title":"专属颜色 2017款科迈罗SS 50周年版","type":"新车","time":"2016-05-16","indexdetail":"视频展示了科迈罗SS 50周年版，车身使用了专属色彩搭配，还有50周年的喷涂字样。","smallimg":"http://www3.autoimg.cn/newsdfs/g20/M15/60/C9/120x90_0_autohomecar__wKgFWVc5JrKAaaHWAAEMDD1zMIw891.jpg","replycount":7,"playcount":3248,"nickname":"崔海","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_1_80585.html","updatetime":"20160516094732","lastid":"201605160947332016051708350080585"},{"id":80581,"title":"玩得好过瘾 俄罗斯越野车水沟暴强越野","type":"花边","time":"2016-05-16","indexdetail":"俄罗斯越野车水沟暴强越野","smallimg":"http://www3.autoimg.cn/newsdfs/g17/M00/79/27/120x90_0_autohomecar__wKjBxlc5JQOAHyUiAAGIS6hmSa0775.jpg","replycount":5,"playcount":6374,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80581.html","updatetime":"20160516094021","lastid":"201605160940212016051708350080581"},{"id":80579,"title":"威风凛凛！实拍蝙蝠侠战车暴走炫酷","type":"花边","time":"2016-05-16","indexdetail":"实拍蝙蝠侠战车暴走炫酷","smallimg":"http://www3.autoimg.cn/newsdfs/g7/M09/7F/16/120x90_0_autohomecar__wKgH3Vc5JLKAVhn0AADtL6fEFzE974.jpg","replycount":5,"playcount":4960,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80579.html","updatetime":"20160516093859","lastid":"201605160938592016051708350080579"},{"id":80577,"title":"闲了就任性一把 拖拉机草地漂移翻车","type":"花边","time":"2016-05-16","indexdetail":"拖拉机草地漂移翻车","smallimg":"http://www2.autoimg.cn/newsdfs/g21/M10/5F/CB/120x90_0_autohomecar__wKgFWlc5I_GACNrlAADDyprMlT4327.jpg","replycount":4,"playcount":4621,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80577.html","updatetime":"20160516093558","lastid":"201605160935582016051708350080577"},{"id":80622,"title":"时尚运动的中型车 西玛 16款 XL 豪华版","type":"到店实拍","time":"2016-05-16","indexdetail":"到店实拍 西玛 2016款 2.5L XL 豪华版","smallimg":"http://www3.autoimg.cn/newsdfs/g7/M08/7E/6A/120x90_0_autohomecar__wKgHzlc5OqiAQPEzAAF7Dbe4NyY496.jpg","replycount":147,"playcount":87885,"nickname":"宋超","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_9_80622.html","updatetime":"20160516115623","lastid":"201605161156242016051617212680622"},{"id":80584,"title":"速度是祸首 大排量摩托车撞车事故合辑","type":"花边","time":"2016-05-16","indexdetail":"大排量摩托车撞车事故合辑","smallimg":"http://www2.autoimg.cn/newsdfs/g4/M09/7D/E0/120x90_0_autohomecar__wKgHy1c5JY6AAADjAADsfuCRAr0948.jpg","replycount":216,"playcount":93896,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80584.html","updatetime":"20160516094240","lastid":"201605160942402016051612565780584"},{"id":80587,"title":"声浪浑厚 AC Schnitzer改装宝马4系排气","type":"花边","time":"2016-05-16","indexdetail":"AC Schnitzer改装宝马4系排气","smallimg":"http://www3.autoimg.cn/newsdfs/g21/M0E/60/05/120x90_0_autohomecar__wKgFVVc5JvmALxNjAAE1PbEYOmI010.jpg","replycount":13,"playcount":4513,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80587.html","updatetime":"20160517091251","lastid":"201605160948442016051612564780587"},{"id":80596,"title":"各种炫酷涂装 国外超跑性能车聚会炫酷","type":"花边","time":"2016-05-16","indexdetail":"国外超跑性能车聚会炫酷","smallimg":"http://www2.autoimg.cn/newsdfs/g4/M11/7E/5F/120x90_0_autohomecar__wKjB01c5KOyAK7BgAAF0S-bG5Fo429.jpg","replycount":5,"playcount":4660,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80596.html","updatetime":"20160516095702","lastid":"201605160957022016051612563580596"}]
     */

    private ResultBean result;
    /**
     * result : {"isloadmore":true,"rowcount":67274,"pagecount":3204,"pageindex":0,"list":[{"id":80676,"title":"《爱极客》 虽安逸 待变革之沃尔沃XC60","type":"花边","time":"2016-05-17","indexdetail":"爱极客原创视频","smallimg":"http://www2.autoimg.cn/newsdfs/g12/M0D/81/FC/120x90_0_autohomecar__wKgH4lc6hR6AEMnqAAG9zW97cwg773.jpg","replycount":2,"playcount":167,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80676.html","updatetime":"20160517104239","lastid":"201605171042402016051710432480676"},{"id":80633,"title":"能拉又能跑 海外试驾本田Ridgeline","type":"试车","time":"2016-05-17","indexdetail":"视频中主持人带来了本田Ridgeline的试驾，它搭载一台来自Pilot的3.5L V6发动机，同时，该车还将装配一套全时四驱系统。","smallimg":"http://www3.autoimg.cn/newsdfs/g17/M10/79/AA/120x90_0_autohomecar__wKjBxlc5cuiACb_qAAFdfYNR2-k538.jpg","replycount":47,"playcount":20346,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_2_80633.html","updatetime":"20160516164339","lastid":"201605170015052016051708513280633"},{"id":80609,"title":"福特F-150 Raptor/Titan XD全面对比","type":"花边","time":"2016-05-16","indexdetail":"视频展示了福特F-150 Raptor与日产Titan XD的全面对比。让我们来看看谁才是硬汉？","smallimg":"http://www2.autoimg.cn/newsdfs/g17/M00/7A/3D/120x90_0_autohomecar__wKgH51c5LiqAXpzgAAFbbPybbDM203.jpg","replycount":14,"playcount":8476,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80609.html","updatetime":"20160516171842","lastid":"201605161718422016051708350080609"},{"id":80593,"title":"经典时刻 最年轻的F1世界冠军TOP 5","type":"花边","time":"2016-05-16","indexdetail":"视频盘点了史上最年轻的F1世界冠军TOP 5。如果你了解F1的话，看看你又认识几位？","smallimg":"http://www2.autoimg.cn/newsdfs/g13/M04/7E/C7/120x90_0_autohomecar__wKgH1Fc5KC6AP4h8AAE2I1ogSeU206.jpg","replycount":17,"playcount":6671,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80593.html","updatetime":"20160516171643","lastid":"201605161716442016051708350080593"},{"id":80631,"title":"太残忍了 实拍小轿车路口被撞成两半","type":"花边","time":"2016-05-16","indexdetail":"太残忍了 实拍小轿车路口被撞成两半","smallimg":"http://www2.autoimg.cn/newsdfs/g14/M12/7D/F2/120x90_0_autohomecar__wKjByVc5YDmAHJRoAAEAS2xdms8722.jpg","replycount":85,"playcount":44354,"nickname":"崔海","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80631.html","updatetime":"20160516135300","lastid":"201605161353002016051708350080631"},{"id":80615,"title":"机增VS自吸 川崎H2加速战宝马S1000RR","type":"花边","time":"2016-05-16","indexdetail":" 机增VS自吸 川崎H2加速战宝马S1000RR ","smallimg":"http://www2.autoimg.cn/newsdfs/g8/M14/81/92/120x90_0_autohomecar__wKgHz1c5Nw6AUT2CAAEh_Log-Tk303.jpg","replycount":93,"playcount":34939,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80615.html","updatetime":"20160516105721","lastid":"201605161057212016051708350080615"},{"id":80614,"title":"超载了吧？实拍手扶拖拉机失控翻车","type":"花边","time":"2016-05-16","indexdetail":" 超载了吧？实拍手扶拖拉机失控翻车 ","smallimg":"http://www2.autoimg.cn/newsdfs/g16/M04/7E/D7/120x90_0_autohomecar__wKgH5lc5NoiABZPeAAFBt1LQq-0322.jpg","replycount":35,"playcount":11844,"nickname":"郝烁","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80614.html","updatetime":"20160516105505","lastid":"201605161055062016051708350080614"},{"id":80613,"title":"这得多快的速度 摩托车路口追尾撞散架","type":"花边","time":"2016-05-16","indexdetail":"视频中的摩托车高速追尾一辆机动车，摩托车散架，画面相当恐怖。","smallimg":"http://www2.autoimg.cn/newsdfs/g10/M15/7F/03/120x90_0_autohomecar__wKgH4Fc5NlWAQ0OLAAFJ3F60o4I047.jpg","replycount":47,"playcount":16869,"nickname":"崔海","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80613.html","updatetime":"20160516105418","lastid":"201605161054182016051708350080613"},{"id":80603,"title":"美式狠角色 道奇蝰蛇400米暴强加速集锦","type":"花边","time":"2016-05-16","indexdetail":"道奇蝰蛇400米暴强加速集锦","smallimg":"http://www3.autoimg.cn/newsdfs/g16/M07/7E/89/120x90_0_autohomecar__wKgH11c5LBqAeXjkAAE_fX7yuhw862.jpg","replycount":38,"playcount":12153,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80603.html","updatetime":"20160517084753","lastid":"201605161010352016051708350080603"},{"id":80601,"title":"这么用功 女司机驾车途中玩电脑入神","type":"花边","time":"2016-05-16","indexdetail":"视频中的女司机在路口等红灯的时候玩电脑，一秒钟都不浪费。","smallimg":"http://www2.autoimg.cn/newsdfs/g9/M06/82/44/120x90_0_autohomecar__wKgH31c5K6OATvxjAAEmwp2-kDI018.jpg","replycount":6,"playcount":4983,"nickname":"崔海","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80601.html","updatetime":"20160516100836","lastid":"201605161008372016051708350080601"},{"id":80595,"title":"加速凶猛！福特野马GT350R赛道飞驰","type":"花边","time":"2016-05-16","indexdetail":"福特野马GT350R赛道飞驰","smallimg":"http://www2.autoimg.cn/newsdfs/g15/M03/7C/72/120x90_0_autohomecar__wKgH5Vc5KKyAJQmOAAEwLV3L_CE149.jpg","replycount":6,"playcount":5145,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80595.html","updatetime":"20160516095558","lastid":"201605160955582016051708350080595"},{"id":80589,"title":"帅！帕加尼Huayra BC冰天雪地测试性能","type":"花边","time":"2016-05-16","indexdetail":"帕加尼Huayra BC冰天雪地测试性能","smallimg":"http://www3.autoimg.cn/newsdfs/g6/M04/7E/2F/120x90_0_autohomecar__wKjB0Vc5J2-AJtkIAACqB7uVD4s649.jpg","replycount":8,"playcount":4144,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80589.html","updatetime":"20160516095040","lastid":"201605160950402016051708350080589"},{"id":80585,"title":"专属颜色 2017款科迈罗SS 50周年版","type":"新车","time":"2016-05-16","indexdetail":"视频展示了科迈罗SS 50周年版，车身使用了专属色彩搭配，还有50周年的喷涂字样。","smallimg":"http://www3.autoimg.cn/newsdfs/g20/M15/60/C9/120x90_0_autohomecar__wKgFWVc5JrKAaaHWAAEMDD1zMIw891.jpg","replycount":7,"playcount":3248,"nickname":"崔海","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_1_80585.html","updatetime":"20160516094732","lastid":"201605160947332016051708350080585"},{"id":80581,"title":"玩得好过瘾 俄罗斯越野车水沟暴强越野","type":"花边","time":"2016-05-16","indexdetail":"俄罗斯越野车水沟暴强越野","smallimg":"http://www3.autoimg.cn/newsdfs/g17/M00/79/27/120x90_0_autohomecar__wKjBxlc5JQOAHyUiAAGIS6hmSa0775.jpg","replycount":5,"playcount":6374,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80581.html","updatetime":"20160516094021","lastid":"201605160940212016051708350080581"},{"id":80579,"title":"威风凛凛！实拍蝙蝠侠战车暴走炫酷","type":"花边","time":"2016-05-16","indexdetail":"实拍蝙蝠侠战车暴走炫酷","smallimg":"http://www3.autoimg.cn/newsdfs/g7/M09/7F/16/120x90_0_autohomecar__wKgH3Vc5JLKAVhn0AADtL6fEFzE974.jpg","replycount":5,"playcount":4960,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80579.html","updatetime":"20160516093859","lastid":"201605160938592016051708350080579"},{"id":80577,"title":"闲了就任性一把 拖拉机草地漂移翻车","type":"花边","time":"2016-05-16","indexdetail":"拖拉机草地漂移翻车","smallimg":"http://www2.autoimg.cn/newsdfs/g21/M10/5F/CB/120x90_0_autohomecar__wKgFWlc5I_GACNrlAADDyprMlT4327.jpg","replycount":4,"playcount":4621,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80577.html","updatetime":"20160516093558","lastid":"201605160935582016051708350080577"},{"id":80622,"title":"时尚运动的中型车 西玛 16款 XL 豪华版","type":"到店实拍","time":"2016-05-16","indexdetail":"到店实拍 西玛 2016款 2.5L XL 豪华版","smallimg":"http://www3.autoimg.cn/newsdfs/g7/M08/7E/6A/120x90_0_autohomecar__wKgHzlc5OqiAQPEzAAF7Dbe4NyY496.jpg","replycount":147,"playcount":87885,"nickname":"宋超","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_9_80622.html","updatetime":"20160516115623","lastid":"201605161156242016051617212680622"},{"id":80584,"title":"速度是祸首 大排量摩托车撞车事故合辑","type":"花边","time":"2016-05-16","indexdetail":"大排量摩托车撞车事故合辑","smallimg":"http://www2.autoimg.cn/newsdfs/g4/M09/7D/E0/120x90_0_autohomecar__wKgHy1c5JY6AAADjAADsfuCRAr0948.jpg","replycount":216,"playcount":93896,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80584.html","updatetime":"20160516094240","lastid":"201605160942402016051612565780584"},{"id":80587,"title":"声浪浑厚 AC Schnitzer改装宝马4系排气","type":"花边","time":"2016-05-16","indexdetail":"AC Schnitzer改装宝马4系排气","smallimg":"http://www3.autoimg.cn/newsdfs/g21/M0E/60/05/120x90_0_autohomecar__wKgFVVc5JvmALxNjAAE1PbEYOmI010.jpg","replycount":13,"playcount":4513,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80587.html","updatetime":"20160517091251","lastid":"201605160948442016051612564780587"},{"id":80596,"title":"各种炫酷涂装 国外超跑性能车聚会炫酷","type":"花边","time":"2016-05-16","indexdetail":"国外超跑性能车聚会炫酷","smallimg":"http://www2.autoimg.cn/newsdfs/g4/M11/7E/5F/120x90_0_autohomecar__wKjB01c5KOyAK7BgAAF0S-bG5Fo429.jpg","replycount":5,"playcount":4660,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80596.html","updatetime":"20160516095702","lastid":"201605160957022016051612563580596"}]}
     * returncode : 0
     * message :
     */

    private int returncode;
    private String message;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class ResultBean {
        private boolean isloadmore;
        private int rowcount;
        private int pagecount;
        private int pageindex;
        /**
         * id : 80676
         * title : 《爱极客》 虽安逸 待变革之沃尔沃XC60
         * type : 花边
         * time : 2016-05-17
         * indexdetail : 爱极客原创视频
         * smallimg : http://www2.autoimg.cn/newsdfs/g12/M0D/81/FC/120x90_0_autohomecar__wKgH4lc6hR6AEMnqAAG9zW97cwg773.jpg
         * replycount : 2
         * playcount : 167
         * nickname : 陆维
         * videoaddress : http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8
         * shareaddress : http://v.autohome.com.cn/v_4_80676.html
         * updatetime : 20160517104239
         * lastid : 201605171042402016051710432480676
         */

        private List<ListBean> list;

        public boolean isIsloadmore() {
            return isloadmore;
        }

        public void setIsloadmore(boolean isloadmore) {
            this.isloadmore = isloadmore;
        }

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public int getPagecount() {
            return pagecount;
        }

        public void setPagecount(int pagecount) {
            this.pagecount = pagecount;
        }

        public int getPageindex() {
            return pageindex;
        }

        public void setPageindex(int pageindex) {
            this.pageindex = pageindex;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean {
            private int id;
            private String title;
            private String type;
            private String time;
            private String indexdetail;
            private String smallimg;
            private int replycount;
            private int playcount;
            private String nickname;
            private String videoaddress;
            private String shareaddress;
            private String updatetime;
            private String lastid;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getIndexdetail() {
                return indexdetail;
            }

            public void setIndexdetail(String indexdetail) {
                this.indexdetail = indexdetail;
            }

            public String getSmallimg() {
                return smallimg;
            }

            public void setSmallimg(String smallimg) {
                this.smallimg = smallimg;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPlaycount() {
                return playcount;
            }

            public void setPlaycount(int playcount) {
                this.playcount = playcount;
            }

            public String getNickname() {
                return nickname;
            }

            public void setNickname(String nickname) {
                this.nickname = nickname;
            }

            public String getVideoaddress() {
                return videoaddress;
            }

            public void setVideoaddress(String videoaddress) {
                this.videoaddress = videoaddress;
            }

            public String getShareaddress() {
                return shareaddress;
            }

            public void setShareaddress(String shareaddress) {
                this.shareaddress = shareaddress;
            }

            public String getUpdatetime() {
                return updatetime;
            }

            public void setUpdatetime(String updatetime) {
                this.updatetime = updatetime;
            }

            public String getLastid() {
                return lastid;
            }

            public void setLastid(String lastid) {
                this.lastid = lastid;
            }
        }
    }
}
