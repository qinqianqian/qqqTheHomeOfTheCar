package com.qqq.thehomeofthecar.bean;

import java.util.List;

/**
 * Created by 秦谦谦 on 16/5/11 19:19.
 */
public class NewFragmentBean {

    /**
     * rowcount : 10203
     * pagecount : 341
     * pageindex : 1
     * headlineinfo : {"id":888409,"title":"2016年4月国内热销SUV/轿车/MPV排行榜","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g12/M05/7B/14/160x120_0_autohomecar__wKgH4lcy3oiAYkQ3AAFK4qUNKsk160.jpg","replycount":859,"pagecount":0,"jumppage":1,"lasttime":""}
     * focusimg : [{"id":518077,"imgurl":"http://www3.autoimg.cn/newsdfs/g20/M08/5B/7A/640x320_0_autohomecar__wKgFVFcy_uiALP5cAAdZvw6u3aY687.jpg","title":"带你触碰只有20辆的帕加尼Huayra BC","type":"","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":3},{"id":888389,"imgurl":"http://www2.autoimg.cn/newsdfs/g15/M01/76/54/640x320_0_autohomecar__wKgH5VcyIIKAJUTsAAfZrrNPHkg822.jpg","title":"日趋成熟/配置丰富 试驾北汽绅宝X35","type":"试驾评测","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1},{"id":80337,"imgurl":"http://www2.autoimg.cn/newsdfs/g8/M03/70/AC/640x320_0_autohomecar__wKjBz1cxkPCAHN85AAcVaaCLqcQ394.jpg","title":"手机也有安全座椅 聊聊手机支架的选择","type":"原创","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":2},{"id":52274741,"imgurl":"http://www2.autoimg.cn/newsdfs/g5/M0B/78/FA/640x320_0_autohomecar__wKgH21cyCqaAUFMlAAJ8tT3CMqE434.jpg","title":"送母亲的礼物 任性提Cayenne 3.0T","type":"","replycount":0,"pageindex":172,"JumpType":0,"jumpurl":"","mediatype":4},{"id":52263680,"imgurl":"http://www2.autoimg.cn/newsdfs/g12/M06/78/36/640x320_0_autohomecar__wKjBy1cwvt6AC6qqAAKCL4SZ84A516.jpg","title":"给老婆开新车 提奥迪A5 45TFSI分享","type":"","replycount":0,"pageindex":538,"JumpType":0,"jumpurl":"","mediatype":4},{"id":888352,"imgurl":"http://www3.autoimg.cn/newsdfs/g4/M10/76/84/640x320_0_autohomecar__wKgHy1cxG4-ADptQAAcfr3bwjcY027.jpg","title":"年轻就要更运动 试驾东风日产新款骐达","type":"试驾评测","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1}]
     * newslist : [{"id":517605,"title":"日系中型车：雅阁凯美瑞为何风光不再？","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M0E/5B/55/160x120_0_autohomecar__wKgFWVcyysCAH4pPAANtaxTotLM347.jpg","replycount":234,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80366,"title":"4X4越野赛 Jeep牧马人挑战艰难路段","mediatype":3,"type":"花边","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g21/M11/59/E2/240x180_0_autohomecar__wKjBwlcykKqAAWSqAAGdVJgsoYQ267.jpg","replycount":13823,"pagecount":0,"jumppage":1,"lasttime":""},{"id":515481,"title":"世界风洞系列：奔驰气动-声学风洞","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g22/M07/3C/90/160x120_0_autohomecar__wKgFW1cUPziAHA_kAAdq67MIaDw322.jpg","replycount":71,"pagecount":0,"jumppage":1,"lasttime":""},{"id":3426204,"title":"更注重实用性 smart forfour","mediatype":6,"type":"1","time":"2016-05-11","indexdetail":"1004㊣25995㊣http://car2.autoimg.cn/cardfs/product/g6/M13/77/AC/t_autohomecar__wKgHzVcx1NuAMbAnAArOo-HmK9M669.jpg,http://car3.autoimg.cn/cardfs/product/g6/M0A/77/D3/t_autohomecar__wKjB0Vcx1NmAdvkEAAjOxXcj_kg593.jpg,http://car3.autoimg.cn/cardfs/product/g6/M00/78/54/t_autohomecar__wKgH3Fcx1NeAHuq1AAkass3PlFE505.jpg","smallpic":"","replycount":141,"pagecount":0,"jumppage":2,"lasttime":""},{"id":888412,"title":"5月12日0时：90号汽油上调0.09元/升","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M0A/75/0E/160x120_0_autohomecar__wKgH51cy-yeAaVP8AAFH-p1wt-U540.jpg","replycount":0,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888389,"title":"日趋成熟/配置丰富 试驾北汽绅宝X35","mediatype":1,"type":"试驾评测","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g15/M13/79/B5/160x120_0_autohomecar__wKgH1lcyIHuABcctAAGJtbP_6K8841.jpg","replycount":176,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80390,"title":"随便漂！阿尔法罗密欧Giulia赛道猛豁","mediatype":3,"type":"花边","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g9/M06/7C/6C/240x180_0_autohomecar__wKgH31cyneqAAMj8AAFBBGKvAcI320.jpg","replycount":13909,"pagecount":0,"jumppage":1,"lasttime":""},{"id":518049,"title":"野马是肌肉车？可能有点问题","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g23/M0A/5B/47/160x120_0_autohomecar__wKjBwFcylJmAU2VoAAHg-xz_F-A588.jpg","replycount":173,"pagecount":0,"jumppage":1,"lasttime":""},{"id":50875932,"title":"外形帅低油耗 谈锋范1.5L提车用车","mediatype":5,"type":"c","time":"2016-05-11","indexdetail":"锋范/锋范经典论坛","smallpic":"http://club2.autoimg.cn/album/g22/M11/15/6C/userphotos/2016/03/27/19/240180_wKgFVlb3xgyAQUqFAAEznTjzdUo012.jpg","replycount":386,"pagecount":0,"jumppage":3876,"lasttime":""},{"id":518077,"title":"带你触碰只有20辆的帕加尼Huayra BC","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g19/M13/5A/FB/160x120_0_autohomecar__wKgFU1cyyGyAGzWnAAN4IaIrxLM761.jpg","replycount":95,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888409,"title":"2016年4月国内热销SUV/轿车/MPV排行榜","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g12/M05/7B/14/160x120_0_autohomecar__wKgH4lcy3oiAYkQ3AAFK4qUNKsk160.jpg","replycount":859,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80380,"title":"这也太狠了 小轿车狂飙飞车失控撞树","mediatype":3,"type":"花边","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g12/M0A/77/2E/240x180_0_autohomecar__wKgH01cyla-AXU3yAAEkt80gOLw961.jpg","replycount":50708,"pagecount":0,"jumppage":1,"lasttime":""},{"id":518027,"title":"大众纽北圈速超本田，跟消费者有关吗？","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M0A/5A/17/160x120_0_autohomecar__wKjBw1cx_seAY0LGAAXyJcOng6k355.jpg","replycount":429,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888408,"title":"大众：速腾召回补救措施基本完成验证","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g15/M0A/7A/57/160x120_0_autohomecar__wKgH1lcy4SmAYUfDAAFKXS5evjo121.jpg","replycount":770,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80373,"title":"性能太恐怖 法拉利FXX K赛道狂秀声浪","mediatype":3,"type":"花边","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M11/5A/B1/240x180_0_autohomecar__wKjBwVcyks2ASu4SAAD9oah27Lo184.jpg","replycount":22875,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517723,"title":"售价28万！三菱劲畅Vs北汽BJ80民用版","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g11/M04/75/9E/160x120_0_autohomecar__wKgH0lcvBzeAJlnEAAEASfGbQZc150.jpg","replycount":361,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888291,"title":"2016亚洲CES：宝马全新概念车亚洲首发","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g9/M0E/7C/B0/160x120_0_autohomecar__wKgH31cyztOAP-dzAAFvD9tU9lk940.jpg","replycount":104,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888407,"title":"售15.59万 上汽大众新款朗逸运动版上市","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M08/5B/98/160x120_0_autohomecar__wKgFVlcy1BaAFqPeAAFBlUpWajY632.jpg","replycount":1324,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80371,"title":"直线厮杀 宝马335i E92 vs 奥迪TT RS","mediatype":3,"type":"花边","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M0F/78/EF/240x180_0_autohomecar__wKgH0lcykgSAfvUzAAFZvvC5pe8545.jpg","replycount":30753,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517994,"title":"到底哪些因素决定一台二手车的价格？","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g13/M15/79/2A/160x120_0_autohomecar__wKgH41cx2aGABrj5AAWWryWvXgU813.jpg","replycount":147,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80391,"title":"幕幕惊险 纽北赛道雨中飙车的意外事故","mediatype":3,"type":"事件","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g9/M0E/7B/D9/240x180_0_autohomecar__wKgH0FcynemAUcCuAAFU1TM-xug788.jpg","replycount":27800,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888403,"title":"造型更激进 全新科迈罗Z/28谍照曝光","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M02/5B/78/160x120_0_autohomecar__wKjBwFcyu6uARLsCAAGYJLyLdag819.jpg","replycount":116,"pagecount":0,"jumppage":1,"lasttime":""},{"id":518020,"title":"大众尾气门亏1200亿 在中国三年赚回来?","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g13/M00/78/E0/160x120_0_autohomecar__wKgH1FcyjDuAJDjcAAFvXgEYJ-k229.jpg","replycount":1374,"pagecount":0,"jumppage":1,"lasttime":""},{"id":52273370,"title":"路上见真招 马自达CX-4试驾直播","mediatype":5,"type":"c","time":"2016-05-11","indexdetail":"马自达CX-4论坛","smallpic":"http://club2.autoimg.cn/album/g18/M0C/78/64/userphotos/2016/05/11/10/240180_wKgH6FcykkqAJAFVAAE6-KnRnl0441.jpg","replycount":1586,"pagecount":0,"jumppage":3968,"lasttime":""},{"id":517220,"title":"他们为什么路怒？左转/调头篇","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M06/51/C3/160x120_0_autohomecar__wKgFWFcpYP-AItFpAAIC8Si9qn0672.jpg","replycount":466,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888401,"title":"基于丰田Hilux打造 PSA将推皮卡车型","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g4/M06/78/C7/160x120_0_autohomecar__wKgH2lcypv-AK99zAAGQbTsoDyA716.jpg","replycount":201,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80387,"title":"实拍最便宜的思域2016款手动豪华版","mediatype":3,"type":"到店实拍","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g12/M03/7A/B9/240x180_0_autohomecar__wKgH4lcynMuADX5bAAEycBfOUXo229.jpg","replycount":98915,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888400,"title":"售24.2万 奔驰B级新增入门级B 180车型","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M00/78/DC/160x120_0_autohomecar__wKjBzVcypwuAU_g_AAFn2QypSv4872.jpg","replycount":448,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888399,"title":"或配V6发动机 全新奥迪RS 5 Coupe谍照","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g6/M02/78/E8/160x120_0_autohomecar__wKgH3FcypciAOOZ5AAISbboItF4501.jpg","replycount":188,"pagecount":0,"jumppage":1,"lasttime":""},{"id":518008,"title":"汉腾汽车跃马奔腾而来","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M0C/5B/87/160x120_0_autohomecar__wKgFXFcyo1SAS00yAAD8pMozmDs210.jpg","replycount":454,"pagecount":0,"jumppage":1,"lasttime":"201605111135004370908"}]
     * topnewsinfo : {}
     */

    private ResultBean result;
    /**
     * result : {"rowcount":10203,"pagecount":341,"pageindex":1,"headlineinfo":{"id":888409,"title":"2016年4月国内热销SUV/轿车/MPV排行榜","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g12/M05/7B/14/160x120_0_autohomecar__wKgH4lcy3oiAYkQ3AAFK4qUNKsk160.jpg","replycount":859,"pagecount":0,"jumppage":1,"lasttime":""},"focusimg":[{"id":518077,"imgurl":"http://www3.autoimg.cn/newsdfs/g20/M08/5B/7A/640x320_0_autohomecar__wKgFVFcy_uiALP5cAAdZvw6u3aY687.jpg","title":"带你触碰只有20辆的帕加尼Huayra BC","type":"","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":3},{"id":888389,"imgurl":"http://www2.autoimg.cn/newsdfs/g15/M01/76/54/640x320_0_autohomecar__wKgH5VcyIIKAJUTsAAfZrrNPHkg822.jpg","title":"日趋成熟/配置丰富 试驾北汽绅宝X35","type":"试驾评测","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1},{"id":80337,"imgurl":"http://www2.autoimg.cn/newsdfs/g8/M03/70/AC/640x320_0_autohomecar__wKjBz1cxkPCAHN85AAcVaaCLqcQ394.jpg","title":"手机也有安全座椅 聊聊手机支架的选择","type":"原创","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":2},{"id":52274741,"imgurl":"http://www2.autoimg.cn/newsdfs/g5/M0B/78/FA/640x320_0_autohomecar__wKgH21cyCqaAUFMlAAJ8tT3CMqE434.jpg","title":"送母亲的礼物 任性提Cayenne 3.0T","type":"","replycount":0,"pageindex":172,"JumpType":0,"jumpurl":"","mediatype":4},{"id":52263680,"imgurl":"http://www2.autoimg.cn/newsdfs/g12/M06/78/36/640x320_0_autohomecar__wKjBy1cwvt6AC6qqAAKCL4SZ84A516.jpg","title":"给老婆开新车 提奥迪A5 45TFSI分享","type":"","replycount":0,"pageindex":538,"JumpType":0,"jumpurl":"","mediatype":4},{"id":888352,"imgurl":"http://www3.autoimg.cn/newsdfs/g4/M10/76/84/640x320_0_autohomecar__wKgHy1cxG4-ADptQAAcfr3bwjcY027.jpg","title":"年轻就要更运动 试驾东风日产新款骐达","type":"试驾评测","replycount":0,"pageindex":1,"JumpType":0,"jumpurl":"","mediatype":1}],"newslist":[{"id":517605,"title":"日系中型车：雅阁凯美瑞为何风光不再？","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M0E/5B/55/160x120_0_autohomecar__wKgFWVcyysCAH4pPAANtaxTotLM347.jpg","replycount":234,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80366,"title":"4X4越野赛 Jeep牧马人挑战艰难路段","mediatype":3,"type":"花边","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g21/M11/59/E2/240x180_0_autohomecar__wKjBwlcykKqAAWSqAAGdVJgsoYQ267.jpg","replycount":13823,"pagecount":0,"jumppage":1,"lasttime":""},{"id":515481,"title":"世界风洞系列：奔驰气动-声学风洞","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g22/M07/3C/90/160x120_0_autohomecar__wKgFW1cUPziAHA_kAAdq67MIaDw322.jpg","replycount":71,"pagecount":0,"jumppage":1,"lasttime":""},{"id":3426204,"title":"更注重实用性 smart forfour","mediatype":6,"type":"1","time":"2016-05-11","indexdetail":"1004㊣25995㊣http://car2.autoimg.cn/cardfs/product/g6/M13/77/AC/t_autohomecar__wKgHzVcx1NuAMbAnAArOo-HmK9M669.jpg,http://car3.autoimg.cn/cardfs/product/g6/M0A/77/D3/t_autohomecar__wKjB0Vcx1NmAdvkEAAjOxXcj_kg593.jpg,http://car3.autoimg.cn/cardfs/product/g6/M00/78/54/t_autohomecar__wKgH3Fcx1NeAHuq1AAkass3PlFE505.jpg","smallpic":"","replycount":141,"pagecount":0,"jumppage":2,"lasttime":""},{"id":888412,"title":"5月12日0时：90号汽油上调0.09元/升","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M0A/75/0E/160x120_0_autohomecar__wKgH51cy-yeAaVP8AAFH-p1wt-U540.jpg","replycount":0,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888389,"title":"日趋成熟/配置丰富 试驾北汽绅宝X35","mediatype":1,"type":"试驾评测","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g15/M13/79/B5/160x120_0_autohomecar__wKgH1lcyIHuABcctAAGJtbP_6K8841.jpg","replycount":176,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80390,"title":"随便漂！阿尔法罗密欧Giulia赛道猛豁","mediatype":3,"type":"花边","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g9/M06/7C/6C/240x180_0_autohomecar__wKgH31cyneqAAMj8AAFBBGKvAcI320.jpg","replycount":13909,"pagecount":0,"jumppage":1,"lasttime":""},{"id":518049,"title":"野马是肌肉车？可能有点问题","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g23/M0A/5B/47/160x120_0_autohomecar__wKjBwFcylJmAU2VoAAHg-xz_F-A588.jpg","replycount":173,"pagecount":0,"jumppage":1,"lasttime":""},{"id":50875932,"title":"外形帅低油耗 谈锋范1.5L提车用车","mediatype":5,"type":"c","time":"2016-05-11","indexdetail":"锋范/锋范经典论坛","smallpic":"http://club2.autoimg.cn/album/g22/M11/15/6C/userphotos/2016/03/27/19/240180_wKgFVlb3xgyAQUqFAAEznTjzdUo012.jpg","replycount":386,"pagecount":0,"jumppage":3876,"lasttime":""},{"id":518077,"title":"带你触碰只有20辆的帕加尼Huayra BC","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g19/M13/5A/FB/160x120_0_autohomecar__wKgFU1cyyGyAGzWnAAN4IaIrxLM761.jpg","replycount":95,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888409,"title":"2016年4月国内热销SUV/轿车/MPV排行榜","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g12/M05/7B/14/160x120_0_autohomecar__wKgH4lcy3oiAYkQ3AAFK4qUNKsk160.jpg","replycount":859,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80380,"title":"这也太狠了 小轿车狂飙飞车失控撞树","mediatype":3,"type":"花边","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g12/M0A/77/2E/240x180_0_autohomecar__wKgH01cyla-AXU3yAAEkt80gOLw961.jpg","replycount":50708,"pagecount":0,"jumppage":1,"lasttime":""},{"id":518027,"title":"大众纽北圈速超本田，跟消费者有关吗？","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M0A/5A/17/160x120_0_autohomecar__wKjBw1cx_seAY0LGAAXyJcOng6k355.jpg","replycount":429,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888408,"title":"大众：速腾召回补救措施基本完成验证","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g15/M0A/7A/57/160x120_0_autohomecar__wKgH1lcy4SmAYUfDAAFKXS5evjo121.jpg","replycount":770,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80373,"title":"性能太恐怖 法拉利FXX K赛道狂秀声浪","mediatype":3,"type":"花边","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M11/5A/B1/240x180_0_autohomecar__wKjBwVcyks2ASu4SAAD9oah27Lo184.jpg","replycount":22875,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517723,"title":"售价28万！三菱劲畅Vs北汽BJ80民用版","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g11/M04/75/9E/160x120_0_autohomecar__wKgH0lcvBzeAJlnEAAEASfGbQZc150.jpg","replycount":361,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888291,"title":"2016亚洲CES：宝马全新概念车亚洲首发","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g9/M0E/7C/B0/160x120_0_autohomecar__wKgH31cyztOAP-dzAAFvD9tU9lk940.jpg","replycount":104,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888407,"title":"售15.59万 上汽大众新款朗逸运动版上市","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M08/5B/98/160x120_0_autohomecar__wKgFVlcy1BaAFqPeAAFBlUpWajY632.jpg","replycount":1324,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80371,"title":"直线厮杀 宝马335i E92 vs 奥迪TT RS","mediatype":3,"type":"花边","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M0F/78/EF/240x180_0_autohomecar__wKgH0lcykgSAfvUzAAFZvvC5pe8545.jpg","replycount":30753,"pagecount":0,"jumppage":1,"lasttime":""},{"id":517994,"title":"到底哪些因素决定一台二手车的价格？","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g13/M15/79/2A/160x120_0_autohomecar__wKgH41cx2aGABrj5AAWWryWvXgU813.jpg","replycount":147,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80391,"title":"幕幕惊险 纽北赛道雨中飙车的意外事故","mediatype":3,"type":"事件","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g9/M0E/7B/D9/240x180_0_autohomecar__wKgH0FcynemAUcCuAAFU1TM-xug788.jpg","replycount":27800,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888403,"title":"造型更激进 全新科迈罗Z/28谍照曝光","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M02/5B/78/160x120_0_autohomecar__wKjBwFcyu6uARLsCAAGYJLyLdag819.jpg","replycount":116,"pagecount":0,"jumppage":1,"lasttime":""},{"id":518020,"title":"大众尾气门亏1200亿 在中国三年赚回来?","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g13/M00/78/E0/160x120_0_autohomecar__wKgH1FcyjDuAJDjcAAFvXgEYJ-k229.jpg","replycount":1374,"pagecount":0,"jumppage":1,"lasttime":""},{"id":52273370,"title":"路上见真招 马自达CX-4试驾直播","mediatype":5,"type":"c","time":"2016-05-11","indexdetail":"马自达CX-4论坛","smallpic":"http://club2.autoimg.cn/album/g18/M0C/78/64/userphotos/2016/05/11/10/240180_wKgH6FcykkqAJAFVAAE6-KnRnl0441.jpg","replycount":1586,"pagecount":0,"jumppage":3968,"lasttime":""},{"id":517220,"title":"他们为什么路怒？左转/调头篇","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M06/51/C3/160x120_0_autohomecar__wKgFWFcpYP-AItFpAAIC8Si9qn0672.jpg","replycount":466,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888401,"title":"基于丰田Hilux打造 PSA将推皮卡车型","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g4/M06/78/C7/160x120_0_autohomecar__wKgH2lcypv-AK99zAAGQbTsoDyA716.jpg","replycount":201,"pagecount":0,"jumppage":1,"lasttime":""},{"id":80387,"title":"实拍最便宜的思域2016款手动豪华版","mediatype":3,"type":"到店实拍","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g12/M03/7A/B9/240x180_0_autohomecar__wKgH4lcynMuADX5bAAEycBfOUXo229.jpg","replycount":98915,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888400,"title":"售24.2万 奔驰B级新增入门级B 180车型","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M00/78/DC/160x120_0_autohomecar__wKjBzVcypwuAU_g_AAFn2QypSv4872.jpg","replycount":448,"pagecount":0,"jumppage":1,"lasttime":""},{"id":888399,"title":"或配V6发动机 全新奥迪RS 5 Coupe谍照","mediatype":1,"type":"新闻中心","time":"2016-05-11","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g6/M02/78/E8/160x120_0_autohomecar__wKgH3FcypciAOOZ5AAISbboItF4501.jpg","replycount":188,"pagecount":0,"jumppage":1,"lasttime":""},{"id":518008,"title":"汉腾汽车跃马奔腾而来","mediatype":2,"type":"","time":"2016-05-11","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M0C/5B/87/160x120_0_autohomecar__wKgFXFcyo1SAS00yAAD8pMozmDs210.jpg","replycount":454,"pagecount":0,"jumppage":1,"lasttime":"201605111135004370908"}],"topnewsinfo":{}}
     * returncode : 0
     * message :
     */

    private int returncode;
    private String message;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class ResultBean {
        private int rowcount;
        private int pagecount;
        private int pageindex;
        /**
         * id : 888409
         * title : 2016年4月国内热销SUV/轿车/MPV排行榜
         * mediatype : 1
         * type : 新闻中心
         * time : 2016-05-11
         * indexdetail :
         * smallpic : http://www3.autoimg.cn/newsdfs/g12/M05/7B/14/160x120_0_autohomecar__wKgH4lcy3oiAYkQ3AAFK4qUNKsk160.jpg
         * replycount : 859
         * pagecount : 0
         * jumppage : 1
         * lasttime :
         */

        private HeadlineinfoBean headlineinfo;
        private TopnewsinfoBean topnewsinfo;
        /**
         * id : 518077
         * imgurl : http://www3.autoimg.cn/newsdfs/g20/M08/5B/7A/640x320_0_autohomecar__wKgFVFcy_uiALP5cAAdZvw6u3aY687.jpg
         * title : 带你触碰只有20辆的帕加尼Huayra BC
         * type :
         * replycount : 0
         * pageindex : 1
         * JumpType : 0
         * jumpurl :
         * mediatype : 3
         */

        private List<FocusimgBean> focusimg;
        /**
         * id : 517605
         * title : 日系中型车：雅阁凯美瑞为何风光不再？
         * mediatype : 2
         * type :
         * time : 2016-05-11
         * indexdetail :
         * smallpic : http://www3.autoimg.cn/newsdfs/g20/M0E/5B/55/160x120_0_autohomecar__wKgFWVcyysCAH4pPAANtaxTotLM347.jpg
         * replycount : 234
         * pagecount : 0
         * jumppage : 1
         * lasttime :
         */

        private List<NewslistBean> newslist;

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public int getPagecount() {
            return pagecount;
        }

        public void setPagecount(int pagecount) {
            this.pagecount = pagecount;
        }

        public int getPageindex() {
            return pageindex;
        }

        public void setPageindex(int pageindex) {
            this.pageindex = pageindex;
        }

        public HeadlineinfoBean getHeadlineinfo() {
            return headlineinfo;
        }

        public void setHeadlineinfo(HeadlineinfoBean headlineinfo) {
            this.headlineinfo = headlineinfo;
        }

        public TopnewsinfoBean getTopnewsinfo() {
            return topnewsinfo;
        }

        public void setTopnewsinfo(TopnewsinfoBean topnewsinfo) {
            this.topnewsinfo = topnewsinfo;
        }

        public List<FocusimgBean> getFocusimg() {
            return focusimg;
        }

        public void setFocusimg(List<FocusimgBean> focusimg) {
            this.focusimg = focusimg;
        }

        public List<NewslistBean> getNewslist() {
            return newslist;
        }

        public void setNewslist(List<NewslistBean> newslist) {
            this.newslist = newslist;
        }

        public static class HeadlineinfoBean {
            private int id;
            private String title;
            private int mediatype;
            private String type;
            private String time;
            private String indexdetail;
            private String smallpic;
            private int replycount;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public int getMediatype() {
                return mediatype;
            }

            public void setMediatype(int mediatype) {
                this.mediatype = mediatype;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getIndexdetail() {
                return indexdetail;
            }

            public void setIndexdetail(String indexdetail) {
                this.indexdetail = indexdetail;
            }

            public String getSmallpic() {
                return smallpic;
            }

            public void setSmallpic(String smallpic) {
                this.smallpic = smallpic;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }
        }

        public static class TopnewsinfoBean {
        }

        public static class FocusimgBean {
            private int id;
            private String imgurl;
            private String title;
            private String type;
            private int replycount;
            private int pageindex;
            private int JumpType;
            private String jumpurl;
            private int mediatype;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getImgurl() {
                return imgurl;
            }

            public void setImgurl(String imgurl) {
                this.imgurl = imgurl;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPageindex() {
                return pageindex;
            }

            public void setPageindex(int pageindex) {
                this.pageindex = pageindex;
            }

            public int getJumpType() {
                return JumpType;
            }

            public void setJumpType(int JumpType) {
                this.JumpType = JumpType;
            }

            public String getJumpurl() {
                return jumpurl;
            }

            public void setJumpurl(String jumpurl) {
                this.jumpurl = jumpurl;
            }

            public int getMediatype() {
                return mediatype;
            }

            public void setMediatype(int mediatype) {
                this.mediatype = mediatype;
            }
        }

        public static class NewslistBean {
            private int id;
            private String title;
            private int mediatype;
            private String type;
            private String time;
            private String indexdetail;
            private String smallpic;
            private int replycount;
            private int pagecount;
            private int jumppage;
            private String lasttime;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public int getMediatype() {
                return mediatype;
            }

            public void setMediatype(int mediatype) {
                this.mediatype = mediatype;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getIndexdetail() {
                return indexdetail;
            }

            public void setIndexdetail(String indexdetail) {
                this.indexdetail = indexdetail;
            }

            public String getSmallpic() {
                return smallpic;
            }

            public void setSmallpic(String smallpic) {
                this.smallpic = smallpic;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPagecount() {
                return pagecount;
            }

            public void setPagecount(int pagecount) {
                this.pagecount = pagecount;
            }

            public int getJumppage() {
                return jumppage;
            }

            public void setJumppage(int jumppage) {
                this.jumppage = jumppage;
            }

            public String getLasttime() {
                return lasttime;
            }

            public void setLasttime(String lasttime) {
                this.lasttime = lasttime;
            }
        }
    }
}
