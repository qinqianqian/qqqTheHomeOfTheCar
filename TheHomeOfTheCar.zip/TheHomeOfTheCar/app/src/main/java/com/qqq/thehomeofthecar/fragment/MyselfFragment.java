package com.qqq.thehomeofthecar.fragment;

import android.view.View;

import com.qqq.thehomeofthecar.R;
import com.qqq.thehomeofthecar.base.BaseFragment;

/**
 * Created by 秦谦谦 on 16/5/9 15:58.
 */
public class MyselfFragment extends BaseFragment {
    @Override
    public int setLayout() {
        return R.layout.fragment_myself;
    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected void initData() {

    }
}
