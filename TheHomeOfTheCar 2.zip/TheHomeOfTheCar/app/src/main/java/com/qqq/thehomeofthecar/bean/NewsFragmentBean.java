package com.qqq.thehomeofthecar.bean;

import java.util.List;

/**
 * Created by 秦谦谦 on 16/5/10 16:51.
 */
public class NewsFragmentBean {
    /**
     * rowcount : 31797
     * isloadmore : true
     * headlineinfo : {}
     * focusimg : []
     * newslist : [{"dbid":0,"id":888347,"title":"或5月上市 奇瑞新款瑞虎3配置信息曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 12:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g8/M08/7A/0F/400x300_0_autohomecar__wKgH3lcweU6AHboJAAF7JilQ_Ns892.jpg","replycount":391,"pagecount":1,"jumppage":1,"lasttime":"20160510120000888347","newstype":0,"updatetime":"20160510164629","coverimages":[]},{"dbid":0,"id":888325,"title":"风阻系数为0.19 奔驰IAA概念车国内首发","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 11:27:18","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M13/5A/19/400x300_0_autohomecar__wKgFVlcxVOqAStVjAAFg6B4-gBo153.jpg","replycount":226,"pagecount":1,"jumppage":1,"lasttime":"20160510112718888325","newstype":0,"updatetime":"20160510113738","coverimages":[]},{"dbid":0,"id":888367,"title":"6月下旬亮相 野马新SUV T80预告图曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 11:19:41","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M04/5A/41/400x300_0_autohomecar__wKgFXFcxUWyAU0kMAAER0hdc568359.jpg","replycount":754,"pagecount":1,"jumppage":1,"lasttime":"20160510111941888367","newstype":0,"updatetime":"20160510111557","coverimages":[]},{"dbid":0,"id":888366,"title":"或2018年发布 法拉利Dino假想图曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:59:51","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M0A/72/0A/400x300_0_autohomecar__wKjBxlcxTSqAVUWkAAEnKtJouUc408.jpg","replycount":198,"pagecount":1,"jumppage":1,"lasttime":"20160510105951888366","newstype":0,"updatetime":"20160510105713","coverimages":[]},{"dbid":0,"id":888364,"title":"2017年3月亮相 捷豹新款F-TYPE谍照曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:46:48","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g21/M04/58/A5/400x300_0_autohomecar__wKjBwlcxR4qARfpwAAGraxqvlVI795.jpg","replycount":66,"pagecount":1,"jumppage":1,"lasttime":"20160510104648888364","newstype":0,"updatetime":"20160510104550","coverimages":[]},{"dbid":0,"id":888361,"title":"约300马力 下代牧马人将搭新2.0T发动机","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:11:35","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M11/76/8D/400x300_0_autohomecar__wKgH1VcxQA6AeqFvAAGn6utUaTQ403.jpg","replycount":445,"pagecount":1,"jumppage":1,"lasttime":"20160510101135888361","newstype":0,"updatetime":"20160510100919","coverimages":[]},{"dbid":0,"id":888359,"title":"2018年换代 新一代标致508信息曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:03:28","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M0C/78/2F/400x300_0_autohomecar__wKgH5FcxOg2AGvENAAFBVAbjBqo249.jpg","replycount":402,"pagecount":1,"jumppage":1,"lasttime":"20160510100328888359","newstype":0,"updatetime":"20160510102119","coverimages":[]},{"dbid":0,"id":888362,"title":"曝兰博基尼Huracan Spyder LP580-2实车","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 9:57:44","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M08/72/7E/400x300_0_autohomecar__wKgH2FcxPymAE3ZqAAFs_Ew4cC4923.jpg","replycount":98,"pagecount":1,"jumppage":1,"lasttime":"20160510095744888362","newstype":0,"updatetime":"20160510095415","coverimages":[]},{"dbid":0,"id":888356,"title":"年内发布 凯迪拉克新款CTS实车曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 9:04:18","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M00/77/5D/400x300_0_autohomecar__wKjBzVcxME2AGw9ZAAGnrITAEuk195.jpg","replycount":483,"pagecount":1,"jumppage":1,"lasttime":"20160510090418888356","newstype":0,"updatetime":"20160510092425","coverimages":[]},{"dbid":0,"id":888349,"title":"搭载YunOS for Car 荣威RX5官图发布","mediatype":10,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 8:00:00","indexdetail":"http://www2.autoimg.cn/newsdfs/g10/M07/76/E7/400x300_0_autohomecar__wKgH0Vcwhk-Af6HgAACtyL-yvsw135.jpg㊣http://www2.autoimg.cn/newsdfs/g10/M01/76/E8/400x300_0_autohomecar__wKgH0VcwhlSALcnOAACyVhOyndw846.jpg㊣http://www3.autoimg.cn/newsdfs/g10/M04/77/03/400x300_0_autohomecar__wKjBzVcwhleAVgFxAADJIq1xVok269.jpg","smallpic":"http://www3.autoimg.cn/newsdfs/g7/M01/76/D5/400x300_0_autohomecar__wKjB0FcxGBmAPP8IAAEyUD8Hemk585.jpg","replycount":1569,"pagecount":1,"jumppage":1,"lasttime":"20160510080000888349","newstype":0,"updatetime":"20160510101204","coverimages":[]},{"dbid":0,"id":888351,"title":"与全新Q7同平台 奥迪Q8将于2018年推出","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 6:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M0F/77/4B/400x300_0_autohomecar__wKgH4FcwliKAbkTGAAFUv8do-dI061.jpg","replycount":603,"pagecount":1,"jumppage":1,"lasttime":"20160510060500888351","newstype":0,"updatetime":"20160509215931","coverimages":[]},{"dbid":0,"id":888345,"title":"2017年推出 上汽大通全新皮卡谍照曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 6:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g7/M14/76/6A/400x300_0_autohomecar__wKjB0FcwcPKAfj9wAAHI0HI4XJU186.jpg","replycount":163,"pagecount":1,"jumppage":1,"lasttime":"20160510060500888345","newstype":0,"updatetime":"20160510112550","coverimages":[]},{"dbid":0,"id":888350,"title":"布局新能源 现代Genesis研发混动系统","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 6:03:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g17/M07/72/B5/400x300_0_autohomecar__wKgH51cwhxiAe0IRAAE5jzcsTPM201.jpg","replycount":117,"pagecount":1,"jumppage":1,"lasttime":"20160510060300888350","newstype":0,"updatetime":"20160509205031","coverimages":[]},{"dbid":0,"id":888348,"title":"或10月亮相 奔驰新E级旅行版最新谍照","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 6:01:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M0D/59/AA/400x300_0_autohomecar__wKgFWVcxMfKAKcWuAAGLOHGUFkY006.jpg","replycount":175,"pagecount":1,"jumppage":1,"lasttime":"20160510060100888348","newstype":0,"updatetime":"20160510085730","coverimages":[]},{"dbid":0,"id":888319,"title":"11城市政策详解 2016年电动车购买宝典","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 0:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M0F/59/01/400x300_0_autohomecar__wKgFVFcwbU6AZyBnAAF8u6RV25c120.jpg","replycount":276,"pagecount":5,"jumppage":1,"lasttime":"20160510000500888319","newstype":0,"updatetime":"20160510101916","coverimages":[]},{"dbid":0,"id":888344,"title":"黑科技来临？本田推活塞可变行程技术","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 20:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g13/M10/77/C9/400x300_0_autohomecar__wKgH41cwbDeAGR_pAADDX1_Y1o4452.jpg","replycount":1106,"pagecount":1,"jumppage":1,"lasttime":"20160509200500888344","newstype":0,"updatetime":"20160509191556","coverimages":[]},{"dbid":0,"id":888305,"title":"定位紧凑型 汉腾首款SUV车型正式发布","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 19:31:29","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g21/M03/58/7F/400x300_0_autohomecar__wKgFVVcwgDKAL0QiAAHrzpMtQzY138.jpg","replycount":1024,"pagecount":1,"jumppage":1,"lasttime":"20160509193129888305","newstype":0,"updatetime":"20160509233728","coverimages":[]},{"dbid":0,"id":888339,"title":"造型升级 雪铁龙新款C4 PICASSO官图","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 17:14:34","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M14/76/94/400x300_0_autohomecar__wKgH11cwUYKAfrKNAAGGuFMs6V4408.jpg","replycount":338,"pagecount":1,"jumppage":1,"lasttime":"20160509171434888339","newstype":0,"updatetime":"20160509170740","coverimages":[]},{"dbid":0,"id":887373,"title":"日本政府针对三菱油耗造假车型展开测试","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 16:35:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M0B/58/AE/400x300_0_autohomecar__wKgFWFcwRiqARS2LAADuy5BAhHw798.jpg","replycount":2549,"pagecount":3,"jumppage":3,"lasttime":"20160509163500887373","newstype":0,"updatetime":"20160509161844","coverimages":[]},{"dbid":0,"id":888337,"title":"造型升级 日产新款骐达将于5月29日上市","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 16:22:16","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M03/76/E0/400x300_0_autohomecar__wKgH0lcwRfKAHPvsAADdbuKY0S4547.jpg","replycount":654,"pagecount":1,"jumppage":1,"lasttime":"20160509162216888337","newstype":0,"updatetime":"20160509190756","coverimages":[]},{"dbid":0,"id":888332,"title":"IHS：氢燃料电池车阻碍重重/前景不看好","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 14:53:33","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g5/M00/76/09/400x300_0_autohomecar__wKjB0lcwMBaATBBKAAGobDYhTTA684.jpg","replycount":208,"pagecount":1,"jumppage":1,"lasttime":"20160509145333888332","newstype":0,"updatetime":"20160509151323","coverimages":[]},{"dbid":0,"id":888331,"title":"1.4T/2.0L可选 国产自由侠5月28日上市","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 14:08:48","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M05/58/73/400x300_0_autohomecar__wKjBwVcwKJ-AXZBLAAEzCJRqYYw923.jpg","replycount":1267,"pagecount":1,"jumppage":1,"lasttime":"20160509140848888331","newstype":0,"updatetime":"20160509140813","coverimages":[]},{"dbid":0,"id":888330,"title":"或再次上涨 油价调价窗口5月11日开启","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 13:41:25","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M0C/58/72/400x300_0_autohomecar__wKgFU1cwIaGAGql8AADpbKDjEls781.jpg","replycount":0,"pagecount":1,"jumppage":1,"lasttime":"20160509134125888330","newstype":0,"updatetime":"20160509134138","coverimages":[]},{"dbid":0,"id":888322,"title":"限量99台 阿斯顿·马丁新超跑更多信息","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 11:11:25","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g15/M02/77/60/400x300_0_autohomecar__wKjByFcv_PaAbkx0AADc_Alllxs703.jpg","replycount":176,"pagecount":1,"jumppage":1,"lasttime":"20160509111125888322","newstype":0,"updatetime":"20160509111059","coverimages":[]},{"dbid":0,"id":888321,"title":"三大领域发力 一汽吉林新车规划曝光","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 11:07:38","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g16/M0A/76/12/400x300_0_autohomecar__wKgH11cv_OKAHrQpAAEavqN49Fk654.jpg","replycount":273,"pagecount":1,"jumppage":1,"lasttime":"20160509110738888321","newstype":0,"updatetime":"20160509110521","coverimages":[]},{"dbid":0,"id":888317,"title":"售73.57/78.15万元 MODEL S 75/75D上市","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 10:13:36","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g6/M08/76/2B/400x300_0_autohomecar__wKgH3Fcv7t6ANJm5AAFA52eWs0I623.jpg","replycount":395,"pagecount":1,"jumppage":1,"lasttime":"20160509101336888317","newstype":0,"updatetime":"20160509101623","coverimages":[]},{"dbid":0,"id":888315,"title":"七座中型SUV 东风风行SX6将于7月上市","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 9:52:28","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g6/M0A/75/78/400x300_0_autohomecar__wKgHzVcv6vWAE7VLAADa0VSBDK4369.jpg","replycount":2288,"pagecount":1,"jumppage":1,"lasttime":"20160509095228888315","newstype":0,"updatetime":"20160509101105","coverimages":[]},{"dbid":0,"id":888309,"title":"硬派回归 雪佛兰Trailblazer量产版官图","mediatype":10,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 6:05:00","indexdetail":"http://www3.autoimg.cn/newsdfs/g10/M08/75/9F/400x300_0_autohomecar__wKgH0VcvSCyAYtXIAACD-K5h548982.jpg㊣http://www2.autoimg.cn/newsdfs/g10/M0F/75/B9/400x300_0_autohomecar__wKjBzVcvSDCAOH9nAACB8o1Fx5Q409.jpg㊣http://www3.autoimg.cn/newsdfs/g10/M05/75/E7/400x300_0_autohomecar__wKgH4FcvSDKARYU9AACF_9zbWp0978.jpg","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M05/75/B8/400x300_0_autohomecar__wKjBzVcvSCiAWGdJAAFVa2_M_rw429.jpg","replycount":459,"pagecount":1,"jumppage":1,"lasttime":"20160509060500888309","newstype":0,"updatetime":"20160508224257","coverimages":[]},{"dbid":0,"id":888307,"title":"年产15万台 五龙汽车贵州建新能源车厂","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 6:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M13/75/15/400x300_0_autohomecar__wKjBzFcvLDOAFDtfAAF2ELtoXVY603.jpg","replycount":390,"pagecount":1,"jumppage":1,"lasttime":"20160509060500888307","newstype":0,"updatetime":"20160509210013","coverimages":[]},{"dbid":0,"id":888311,"title":"阿尔法罗密欧发布Giulia警用版官图","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 6:04:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g9/M12/78/56/400x300_0_autohomecar__wKgH31cvWdKAD0_mAAFwhfE4wTQ522.jpg","replycount":271,"pagecount":1,"jumppage":1,"lasttime":"20160509060400888311","newstype":0,"updatetime":"20160509012525","coverimages":[]}]
     * topnewsinfo : {}
     */

    private ResultBean result;
    /**
     * result : {"rowcount":31797,"isloadmore":true,"headlineinfo":{},"focusimg":[],"newslist":[{"dbid":0,"id":888347,"title":"或5月上市 奇瑞新款瑞虎3配置信息曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 12:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g8/M08/7A/0F/400x300_0_autohomecar__wKgH3lcweU6AHboJAAF7JilQ_Ns892.jpg","replycount":391,"pagecount":1,"jumppage":1,"lasttime":"20160510120000888347","newstype":0,"updatetime":"20160510164629","coverimages":[]},{"dbid":0,"id":888325,"title":"风阻系数为0.19 奔驰IAA概念车国内首发","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 11:27:18","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M13/5A/19/400x300_0_autohomecar__wKgFVlcxVOqAStVjAAFg6B4-gBo153.jpg","replycount":226,"pagecount":1,"jumppage":1,"lasttime":"20160510112718888325","newstype":0,"updatetime":"20160510113738","coverimages":[]},{"dbid":0,"id":888367,"title":"6月下旬亮相 野马新SUV T80预告图曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 11:19:41","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g23/M04/5A/41/400x300_0_autohomecar__wKgFXFcxUWyAU0kMAAER0hdc568359.jpg","replycount":754,"pagecount":1,"jumppage":1,"lasttime":"20160510111941888367","newstype":0,"updatetime":"20160510111557","coverimages":[]},{"dbid":0,"id":888366,"title":"或2018年发布 法拉利Dino假想图曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:59:51","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M0A/72/0A/400x300_0_autohomecar__wKjBxlcxTSqAVUWkAAEnKtJouUc408.jpg","replycount":198,"pagecount":1,"jumppage":1,"lasttime":"20160510105951888366","newstype":0,"updatetime":"20160510105713","coverimages":[]},{"dbid":0,"id":888364,"title":"2017年3月亮相 捷豹新款F-TYPE谍照曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:46:48","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g21/M04/58/A5/400x300_0_autohomecar__wKjBwlcxR4qARfpwAAGraxqvlVI795.jpg","replycount":66,"pagecount":1,"jumppage":1,"lasttime":"20160510104648888364","newstype":0,"updatetime":"20160510104550","coverimages":[]},{"dbid":0,"id":888361,"title":"约300马力 下代牧马人将搭新2.0T发动机","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:11:35","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M11/76/8D/400x300_0_autohomecar__wKgH1VcxQA6AeqFvAAGn6utUaTQ403.jpg","replycount":445,"pagecount":1,"jumppage":1,"lasttime":"20160510101135888361","newstype":0,"updatetime":"20160510100919","coverimages":[]},{"dbid":0,"id":888359,"title":"2018年换代 新一代标致508信息曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 10:03:28","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M0C/78/2F/400x300_0_autohomecar__wKgH5FcxOg2AGvENAAFBVAbjBqo249.jpg","replycount":402,"pagecount":1,"jumppage":1,"lasttime":"20160510100328888359","newstype":0,"updatetime":"20160510102119","coverimages":[]},{"dbid":0,"id":888362,"title":"曝兰博基尼Huracan Spyder LP580-2实车","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 9:57:44","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g17/M08/72/7E/400x300_0_autohomecar__wKgH2FcxPymAE3ZqAAFs_Ew4cC4923.jpg","replycount":98,"pagecount":1,"jumppage":1,"lasttime":"20160510095744888362","newstype":0,"updatetime":"20160510095415","coverimages":[]},{"dbid":0,"id":888356,"title":"年内发布 凯迪拉克新款CTS实车曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 9:04:18","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M00/77/5D/400x300_0_autohomecar__wKjBzVcxME2AGw9ZAAGnrITAEuk195.jpg","replycount":483,"pagecount":1,"jumppage":1,"lasttime":"20160510090418888356","newstype":0,"updatetime":"20160510092425","coverimages":[]},{"dbid":0,"id":888349,"title":"搭载YunOS for Car 荣威RX5官图发布","mediatype":10,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 8:00:00","indexdetail":"http://www2.autoimg.cn/newsdfs/g10/M07/76/E7/400x300_0_autohomecar__wKgH0Vcwhk-Af6HgAACtyL-yvsw135.jpg㊣http://www2.autoimg.cn/newsdfs/g10/M01/76/E8/400x300_0_autohomecar__wKgH0VcwhlSALcnOAACyVhOyndw846.jpg㊣http://www3.autoimg.cn/newsdfs/g10/M04/77/03/400x300_0_autohomecar__wKjBzVcwhleAVgFxAADJIq1xVok269.jpg","smallpic":"http://www3.autoimg.cn/newsdfs/g7/M01/76/D5/400x300_0_autohomecar__wKjB0FcxGBmAPP8IAAEyUD8Hemk585.jpg","replycount":1569,"pagecount":1,"jumppage":1,"lasttime":"20160510080000888349","newstype":0,"updatetime":"20160510101204","coverimages":[]},{"dbid":0,"id":888351,"title":"与全新Q7同平台 奥迪Q8将于2018年推出","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 6:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M0F/77/4B/400x300_0_autohomecar__wKgH4FcwliKAbkTGAAFUv8do-dI061.jpg","replycount":603,"pagecount":1,"jumppage":1,"lasttime":"20160510060500888351","newstype":0,"updatetime":"20160509215931","coverimages":[]},{"dbid":0,"id":888345,"title":"2017年推出 上汽大通全新皮卡谍照曝光","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 6:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g7/M14/76/6A/400x300_0_autohomecar__wKjB0FcwcPKAfj9wAAHI0HI4XJU186.jpg","replycount":163,"pagecount":1,"jumppage":1,"lasttime":"20160510060500888345","newstype":0,"updatetime":"20160510112550","coverimages":[]},{"dbid":0,"id":888350,"title":"布局新能源 现代Genesis研发混动系统","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 6:03:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g17/M07/72/B5/400x300_0_autohomecar__wKgH51cwhxiAe0IRAAE5jzcsTPM201.jpg","replycount":117,"pagecount":1,"jumppage":1,"lasttime":"20160510060300888350","newstype":0,"updatetime":"20160509205031","coverimages":[]},{"dbid":0,"id":888348,"title":"或10月亮相 奔驰新E级旅行版最新谍照","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 6:01:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g20/M0D/59/AA/400x300_0_autohomecar__wKgFWVcxMfKAKcWuAAGLOHGUFkY006.jpg","replycount":175,"pagecount":1,"jumppage":1,"lasttime":"20160510060100888348","newstype":0,"updatetime":"20160510085730","coverimages":[]},{"dbid":0,"id":888319,"title":"11城市政策详解 2016年电动车购买宝典","mediatype":0,"type":"新闻中心","time":"2016-05-10","intacttime":"2016/5/10 0:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g20/M0F/59/01/400x300_0_autohomecar__wKgFVFcwbU6AZyBnAAF8u6RV25c120.jpg","replycount":276,"pagecount":5,"jumppage":1,"lasttime":"20160510000500888319","newstype":0,"updatetime":"20160510101916","coverimages":[]},{"dbid":0,"id":888344,"title":"黑科技来临？本田推活塞可变行程技术","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 20:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g13/M10/77/C9/400x300_0_autohomecar__wKgH41cwbDeAGR_pAADDX1_Y1o4452.jpg","replycount":1106,"pagecount":1,"jumppage":1,"lasttime":"20160509200500888344","newstype":0,"updatetime":"20160509191556","coverimages":[]},{"dbid":0,"id":888305,"title":"定位紧凑型 汉腾首款SUV车型正式发布","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 19:31:29","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g21/M03/58/7F/400x300_0_autohomecar__wKgFVVcwgDKAL0QiAAHrzpMtQzY138.jpg","replycount":1024,"pagecount":1,"jumppage":1,"lasttime":"20160509193129888305","newstype":0,"updatetime":"20160509233728","coverimages":[]},{"dbid":0,"id":888339,"title":"造型升级 雪铁龙新款C4 PICASSO官图","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 17:14:34","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M14/76/94/400x300_0_autohomecar__wKgH11cwUYKAfrKNAAGGuFMs6V4408.jpg","replycount":338,"pagecount":1,"jumppage":1,"lasttime":"20160509171434888339","newstype":0,"updatetime":"20160509170740","coverimages":[]},{"dbid":0,"id":887373,"title":"日本政府针对三菱油耗造假车型展开测试","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 16:35:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M0B/58/AE/400x300_0_autohomecar__wKgFWFcwRiqARS2LAADuy5BAhHw798.jpg","replycount":2549,"pagecount":3,"jumppage":3,"lasttime":"20160509163500887373","newstype":0,"updatetime":"20160509161844","coverimages":[]},{"dbid":0,"id":888337,"title":"造型升级 日产新款骐达将于5月29日上市","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 16:22:16","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M03/76/E0/400x300_0_autohomecar__wKgH0lcwRfKAHPvsAADdbuKY0S4547.jpg","replycount":654,"pagecount":1,"jumppage":1,"lasttime":"20160509162216888337","newstype":0,"updatetime":"20160509190756","coverimages":[]},{"dbid":0,"id":888332,"title":"IHS：氢燃料电池车阻碍重重/前景不看好","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 14:53:33","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g5/M00/76/09/400x300_0_autohomecar__wKjB0lcwMBaATBBKAAGobDYhTTA684.jpg","replycount":208,"pagecount":1,"jumppage":1,"lasttime":"20160509145333888332","newstype":0,"updatetime":"20160509151323","coverimages":[]},{"dbid":0,"id":888331,"title":"1.4T/2.0L可选 国产自由侠5月28日上市","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 14:08:48","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g22/M05/58/73/400x300_0_autohomecar__wKjBwVcwKJ-AXZBLAAEzCJRqYYw923.jpg","replycount":1267,"pagecount":1,"jumppage":1,"lasttime":"20160509140848888331","newstype":0,"updatetime":"20160509140813","coverimages":[]},{"dbid":0,"id":888330,"title":"或再次上涨 油价调价窗口5月11日开启","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 13:41:25","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g19/M0C/58/72/400x300_0_autohomecar__wKgFU1cwIaGAGql8AADpbKDjEls781.jpg","replycount":0,"pagecount":1,"jumppage":1,"lasttime":"20160509134125888330","newstype":0,"updatetime":"20160509134138","coverimages":[]},{"dbid":0,"id":888322,"title":"限量99台 阿斯顿·马丁新超跑更多信息","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 11:11:25","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g15/M02/77/60/400x300_0_autohomecar__wKjByFcv_PaAbkx0AADc_Alllxs703.jpg","replycount":176,"pagecount":1,"jumppage":1,"lasttime":"20160509111125888322","newstype":0,"updatetime":"20160509111059","coverimages":[]},{"dbid":0,"id":888321,"title":"三大领域发力 一汽吉林新车规划曝光","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 11:07:38","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g16/M0A/76/12/400x300_0_autohomecar__wKgH11cv_OKAHrQpAAEavqN49Fk654.jpg","replycount":273,"pagecount":1,"jumppage":1,"lasttime":"20160509110738888321","newstype":0,"updatetime":"20160509110521","coverimages":[]},{"dbid":0,"id":888317,"title":"售73.57/78.15万元 MODEL S 75/75D上市","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 10:13:36","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g6/M08/76/2B/400x300_0_autohomecar__wKgH3Fcv7t6ANJm5AAFA52eWs0I623.jpg","replycount":395,"pagecount":1,"jumppage":1,"lasttime":"20160509101336888317","newstype":0,"updatetime":"20160509101623","coverimages":[]},{"dbid":0,"id":888315,"title":"七座中型SUV 东风风行SX6将于7月上市","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 9:52:28","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g6/M0A/75/78/400x300_0_autohomecar__wKgHzVcv6vWAE7VLAADa0VSBDK4369.jpg","replycount":2288,"pagecount":1,"jumppage":1,"lasttime":"20160509095228888315","newstype":0,"updatetime":"20160509101105","coverimages":[]},{"dbid":0,"id":888309,"title":"硬派回归 雪佛兰Trailblazer量产版官图","mediatype":10,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 6:05:00","indexdetail":"http://www3.autoimg.cn/newsdfs/g10/M08/75/9F/400x300_0_autohomecar__wKgH0VcvSCyAYtXIAACD-K5h548982.jpg㊣http://www2.autoimg.cn/newsdfs/g10/M0F/75/B9/400x300_0_autohomecar__wKjBzVcvSDCAOH9nAACB8o1Fx5Q409.jpg㊣http://www3.autoimg.cn/newsdfs/g10/M05/75/E7/400x300_0_autohomecar__wKgH4FcvSDKARYU9AACF_9zbWp0978.jpg","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M05/75/B8/400x300_0_autohomecar__wKjBzVcvSCiAWGdJAAFVa2_M_rw429.jpg","replycount":459,"pagecount":1,"jumppage":1,"lasttime":"20160509060500888309","newstype":0,"updatetime":"20160508224257","coverimages":[]},{"dbid":0,"id":888307,"title":"年产15万台 五龙汽车贵州建新能源车厂","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 6:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M13/75/15/400x300_0_autohomecar__wKjBzFcvLDOAFDtfAAF2ELtoXVY603.jpg","replycount":390,"pagecount":1,"jumppage":1,"lasttime":"20160509060500888307","newstype":0,"updatetime":"20160509210013","coverimages":[]},{"dbid":0,"id":888311,"title":"阿尔法罗密欧发布Giulia警用版官图","mediatype":0,"type":"新闻中心","time":"2016-05-09","intacttime":"2016/5/9 6:04:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g9/M12/78/56/400x300_0_autohomecar__wKgH31cvWdKAD0_mAAFwhfE4wTQ522.jpg","replycount":271,"pagecount":1,"jumppage":1,"lasttime":"20160509060400888311","newstype":0,"updatetime":"20160509012525","coverimages":[]}],"topnewsinfo":{}}
     * returncode : 0
     * message :
     */

    private int returncode;
    private String message;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class ResultBean {
        private int rowcount;
        private boolean isloadmore;
        private List<?> focusimg;
        /**
         * dbid : 0
         * id : 888347
         * title : 或5月上市 奇瑞新款瑞虎3配置信息曝光
         * mediatype : 0
         * type : 新闻中心
         * time : 2016-05-10
         * intacttime : 2016/5/10 12:00:00
         * indexdetail :
         * smallpic : http://www3.autoimg.cn/newsdfs/g8/M08/7A/0F/400x300_0_autohomecar__wKgH3lcweU6AHboJAAF7JilQ_Ns892.jpg
         * replycount : 391
         * pagecount : 1
         * jumppage : 1
         * lasttime : 20160510120000888347
         * newstype : 0
         * updatetime : 20160510164629
         * coverimages : []
         */

        private List<NewslistBean> newslist;


        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public boolean isIsloadmore() {
            return isloadmore;
        }

        public void setIsloadmore(boolean isloadmore) {
            this.isloadmore = isloadmore;
        }

        public List<?> getFocusimg() {
            return focusimg;
        }

        public void setFocusimg(List<?> focusimg) {
            this.focusimg = focusimg;
        }

        public List<NewslistBean> getNewslist() {
            return newslist;
        }

        public void setNewslist(List<NewslistBean> newslist) {
            this.newslist = newslist;
        }

        public static class NewslistBean {
            private int dbid;
            private int id;
            private String title;
            private int mediatype;
            private String type;
            private String time;
            private String intacttime;
            private String indexdetail;
            private String smallpic;
            private int replycount;
            private int pagecount;
            private int jumppage;
            private String lasttime;
            private int newstype;
            private String updatetime;
            private List<?> coverimages;

            public int getDbid() {
                return dbid;
            }

            public void setDbid(int dbid) {
                this.dbid = dbid;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public int getMediatype() {
                return mediatype;
            }

            public void setMediatype(int mediatype) {
                this.mediatype = mediatype;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getIntacttime() {
                return intacttime;
            }

            public void setIntacttime(String intacttime) {
                this.intacttime = intacttime;
            }

            public String getIndexdetail() {
                return indexdetail;
            }

            public void setIndexdetail(String indexdetail) {
                this.indexdetail = indexdetail;
            }

            public String getSmallpic() {
                return smallpic;
            }

            public void setSmallpic(String smallpic) {
                this.smallpic = smallpic;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPagecount() {
                return pagecount;
            }

            public void setPagecount(int pagecount) {
                this.pagecount = pagecount;
            }

            public int getJumppage() {
                return jumppage;
            }

            public void setJumppage(int jumppage) {
                this.jumppage = jumppage;
            }

            public String getLasttime() {
                return lasttime;
            }

            public void setLasttime(String lasttime) {
                this.lasttime = lasttime;
            }

            public int getNewstype() {
                return newstype;
            }

            public void setNewstype(int newstype) {
                this.newstype = newstype;
            }

            public String getUpdatetime() {
                return updatetime;
            }

            public void setUpdatetime(String updatetime) {
                this.updatetime = updatetime;
            }

            public List<?> getCoverimages() {
                return coverimages;
            }

            public void setCoverimages(List<?> coverimages) {
                this.coverimages = coverimages;
            }
        }
    }
}
