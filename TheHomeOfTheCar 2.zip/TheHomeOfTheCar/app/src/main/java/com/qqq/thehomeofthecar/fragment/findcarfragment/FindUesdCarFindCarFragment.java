package com.qqq.thehomeofthecar.fragment.findcarfragment;

import android.view.View;

import com.qqq.thehomeofthecar.R;
import com.qqq.thehomeofthecar.base.BaseFragment;

/**
 * Created by 秦谦谦 on 16/5/10 10:58.
 */
public class FindUesdCarFindCarFragment extends BaseFragment {
    @Override
    public int setLayout() {
        return R.layout.fragment_findcar_findusedcar;
    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected void initData() {

    }
}
