package com.qqq.thehomeofthecar.cycleimage;

/**
 * Created by 秦谦谦 on 16/5/12 17:42.
 */
public class CycleThread implements Runnable{
    private boolean flag=false;

    @Override
    public void run() {
        while (true){

        }
    }
}
