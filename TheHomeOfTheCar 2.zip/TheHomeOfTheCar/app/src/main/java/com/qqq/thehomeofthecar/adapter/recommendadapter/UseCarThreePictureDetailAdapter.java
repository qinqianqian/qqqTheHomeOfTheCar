package com.qqq.thehomeofthecar.adapter.recommendadapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Matrix;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.qqq.thehomeofthecar.R;
import com.qqq.thehomeofthecar.UseCarThreePictureDetailActivity;
import com.qqq.thehomeofthecar.bean.UseCarThreePictureDetailBean;
import com.qqq.thehomeofthecar.util.BroadcastValue;

import java.sql.Time;
import java.util.Timer;
import java.util.TimerTask;

import it.sephiroth.android.library.picasso.Picasso;

/**
 * Created by 秦谦谦 on 16/5/17 17:00.
 */
public class UseCarThreePictureDetailAdapter extends PagerAdapter {
    private UseCarThreePictureDetailBean useCarThreePictureDetailBean;
    private Context context;
    //判断图片的点击事件
    private boolean isChecked = false;
    //判断图片点击了几次
    private static boolean isExit = false;
    private ImageView imageView;

    public UseCarThreePictureDetailAdapter(UseCarThreePictureDetailBean useCarThreePictureDetailBean, Context context) {
        this.useCarThreePictureDetailBean = useCarThreePictureDetailBean;
        this.context = context;
    }

    @Override
    public int getCount() {
        return useCarThreePictureDetailBean == null ? 0 : useCarThreePictureDetailBean.getResult().getImages().size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_usecar_threepicturedetail, container, false);
        imageView = (ImageView) view.findViewById(R.id.usecar_image);

        setImage(imageView, useCarThreePictureDetailBean.getResult().getImages().get(position).getImgurl());

        //ImageView的点击时间
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BroadcastValue.USECAR_THREEPICTERE_CLOSE);
                intent.putExtra("isChecked", isChecked);
                if (isChecked) {
                    isChecked = false;
                } else {
                    isChecked = true;
                }
                context.sendBroadcast(intent);
                //双击图片

               int  time = 0;
                if (!isExit) {
                    Log.d("UseCarThreePictureDetai", "点击一次");
                    isExit = true;
                    Toast.makeText(context, "双击放大图片", Toast.LENGTH_SHORT).show();
                    new Timer().schedule(new TimerTask() {
                        @Override
                        public void run() {
                            isExit = false;
                        }
                    }, 500);
                } else {
                    if (time<3) {
                        Log.d("UseCarThreePictureDetai", "点击两次");
                        time++;
                        scaleAnim();
                    }
                    else {
                        time=0;
                        //缩回原来图片大小
                    }
                }



                }

            //点击几次的点击
            //点击两次图片触发
        });


        container.addView(view);
        return view;
    }





    public void setImage(ImageView imageView, String path) {
        Picasso.with(context).load(path).placeholder(R.mipmap.ahlib_common_main_filter_icon_f).error(R.mipmap.ahlib_common_main_filter_icon_p).into(imageView);

    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {

    }

    //图片的缩放
    public void scaleAnim() {
            ScaleAnimation scaleAnimation = new ScaleAnimation(1,0.5f, 1,0.5f,
                    Animation.RELATIVE_TO_PARENT, 0.5f, Animation.RELATIVE_TO_PARENT, 0.5f);
            Log.d("UseCarThreePictureDetai", "缩放");

            scaleAnimation.setDuration(500);
       // scaleAnimation.setFillAfter(true);
        imageView.startAnimation(scaleAnimation);

    }

}
